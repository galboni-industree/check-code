<?php /* views/layout-header.php — expects $pageTitle */
$cur = basename($_SERVER['SCRIPT_NAME'] ?? '');
function navlink(string $file, string $label, string $cur, string $icon = ''): string {
    $active = $cur === $file ? ' class="active"' : '';
    $ic = $icon ? '<span class="mn-ico">' . $icon . '</span>' : '';
    return '<a' . $active . ' href="' . $file . '">' . $ic . e($label) . '</a>';
}
$unread = db_count('alerts', ['read' => false]);
?>
<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="robots" content="noindex, nofollow">
<meta name="theme-color" content="#14161a">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="CompWatch">
<title><?= e($pageTitle ?? 'CompetitorWatch') ?> — CompetitorWatch</title>
<link rel="manifest" href="manifest.webmanifest">
<link rel="apple-touch-icon" href="assets/apple-touch-icon.png">
<link rel="icon" type="image/png" href="assets/icon-192.png">
<link rel="preload" href="assets/fonts/inter-v20-latin-regular.woff2" as="font" type="font/woff2" crossorigin>
<link rel="preload" href="assets/fonts/baloo-2-v23-latin-600.woff2" as="font" type="font/woff2" crossorigin>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="topbar">
  <div class="topbar-inner">
    <a href="index.php" class="brand">
      <span class="logo-mark"><img src="assets/icon-192.png" width="26" height="26" alt="" style="border-radius:7px"></span>
      CompetitorWatch
    </a>
  </div>
  <div class="mainnav-wrap">
    <button type="button" class="nav-arrow nav-arrow-l" aria-label="Scorri a sinistra" hidden>‹</button>
    <nav class="mainnav" id="mainnav">
      <?= navlink('index.php', 'Dashboard', $cur, '▦') ?>
      <?= navlink('compare.php', 'Confronto', $cur, '⚖') ?>
      <?= navlink('reports.php', 'Report', $cur, '▤') ?>
      <a<?= $cur==='alerts.php'?' class="active"':'' ?> href="alerts.php"><span class="mn-ico">◉</span>Alert<?php if ($unread>0) echo ' <span class="badge">'.e($unread > 99 ? '99+' : $unread).'</span>'; ?></a>
      <?= navlink('status.php', 'Stato', $cur, '⚙') ?>
      <?= navlink('logs.php', 'Log', $cur, '▣') ?>
      <?= navlink('competitors.php', 'Concorrenti', $cur, '👥') ?>
      <?= navlink('settings.php', 'Impostazioni', $cur, '⚙') ?>
    </nav>
    <button type="button" class="nav-arrow nav-arrow-r" aria-label="Scorri a destra" hidden>›</button>
  </div>
</header>
<main class="container">
<?php foreach (flash_get() as $f): ?>
  <div class="flash flash-<?= e($f['type']) ?>"><?= e($f['message']) ?></div>
<?php endforeach; ?>

