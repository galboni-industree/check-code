</main>
<footer class="footer">CompetitorWatch v1.51 — uso interno</footer>
<script>
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(()=>{}));
}
// Navigazione orizzontale: drag col mouse + frecce quando il contenuto sfora
(function(){
  const nav = document.getElementById('mainnav');
  if (!nav) return;
  const wrap = nav.closest('.mainnav-wrap');
  const left = wrap && wrap.querySelector('.nav-arrow-l');
  const right = wrap && wrap.querySelector('.nav-arrow-r');

  function updateArrows(){
    if (!left || !right) return;
    const overflow = nav.scrollWidth > nav.clientWidth + 2;
    const atStart = nav.scrollLeft <= 1;
    const atEnd = nav.scrollLeft >= nav.scrollWidth - nav.clientWidth - 1;
    left.hidden  = !overflow || atStart;
    right.hidden = !overflow || atEnd;
  }
  function scrollByStep(dir){ nav.scrollBy({left: dir * Math.max(160, nav.clientWidth*0.6), behavior:'smooth'}); }
  if (left)  left.addEventListener('click', ()=>scrollByStep(-1));
  if (right) right.addEventListener('click', ()=>scrollByStep(1));
  nav.addEventListener('scroll', updateArrows, {passive:true});
  window.addEventListener('resize', updateArrows);

  // Drag col mouse (desktop)
  let down=false, startX=0, startScroll=0, moved=false;
  nav.addEventListener('mousedown', e=>{ down=true; moved=false; startX=e.pageX; startScroll=nav.scrollLeft; nav.classList.add('dragging'); });
  window.addEventListener('mousemove', e=>{ if(!down) return; const dx=e.pageX-startX; if(Math.abs(dx)>4) moved=true; nav.scrollLeft=startScroll-dx; });
  window.addEventListener('mouseup', ()=>{ down=false; nav.classList.remove('dragging'); });
  // Evita che il drag attivi il click sul link
  nav.addEventListener('click', e=>{ if(moved){ e.preventDefault(); moved=false; } }, true);

  // Porta in vista la voce attiva all'apertura
  const act = nav.querySelector('a.active');
  if (act) act.scrollIntoView({inline:'center', block:'nearest'});
  updateArrows();
})();
</script>
</body>
</html>
