<?php
declare(strict_types=1);

/**
 * CompetitorWatch — Authentication
 *
 * Authentication is handled entirely by Apache Basic Auth (.htaccess).
 * This layer:
 *  1. Detects the Basic Auth username for audit logging
 *  2. Provides require_auth() guard callable from every page
 *  3. Warns loudly if Basic Auth is not active
 */

/**
 * Returns the current Basic Auth username, or 'unknown'.
 * Tries multiple server variables for compatibility with
 * different PHP SAPI configurations (mod_php, FPM, FastCGI).
 */
function current_user(): string
{
    // CLI cron runs have no HTTP auth
    if (PHP_SAPI === 'cli') return 'cron';

    $candidates = [
        'REMOTE_USER',
        'PHP_AUTH_USER',
        'REDIRECT_REMOTE_USER',
        'HTTP_REMOTE_USER',
    ];

    foreach ($candidates as $key) {
        if (!empty($_SERVER[$key])) {
            return (string)$_SERVER[$key];
        }
    }

    return 'unknown';
}

/**
 * Require that Basic Auth is active and user is authenticated.
 *
 * If Basic Auth is configured correctly, Apache will have already
 * challenged the browser before PHP runs — so if we get here
 * without a recognized user, something is misconfigured.
 *
 * We do NOT serve any protected content in that case.
 */
function require_auth(): void
{
    if (PHP_SAPI === 'cli') return; // cron is always allowed

    $user = current_user();

    if ($user === 'unknown') {
        // Basic Auth not active or misconfigured.
        // Show a clear error rather than silently serving content.
        http_response_code(401);
        header('WWW-Authenticate: Basic realm="CompetitorWatch"');
        exit(
            '<h1>401 — Autenticazione richiesta</h1>'
            . '<p>CompetitorWatch è protetto da Basic Authentication.</p>'
            . '<p>Assicurati che le righe Basic Auth in <code>.htaccess</code> '
            . 'siano decommentate e che il file <code>.htpasswd</code> esista.</p>'
            . '<p>Consulta il README per la procedura.</p>'
        );
    }
}
