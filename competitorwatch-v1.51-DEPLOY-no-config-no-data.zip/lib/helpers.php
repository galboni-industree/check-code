<?php
declare(strict_types=1);

// ── Config reader ─────────────────────────────────────────────────────────────

/**
 * Read a config value with dot-notation.
 * config('llm.keys.claude') → $config['llm']['keys']['claude']
 */
function config(string $key, mixed $default = null): mixed
{
    $cfg = $GLOBALS['cw_config'] ?? [];
    foreach (explode('.', $key) as $segment) {
        if (!is_array($cfg) || !array_key_exists($segment, $cfg)) {
            return $default;
        }
        $cfg = $cfg[$segment];
    }
    return $cfg;
}

// ── Formatting ────────────────────────────────────────────────────────────────

function fmt_number(mixed $n): string
{
    return number_format((float)$n, 0, ',', '.');
}

function fmt_pct(mixed $n, int $decimals = 2): string
{
    return number_format((float)$n, $decimals, ',', '.') . '%';
}

function fmt_date(string $dateStr): string
{
    if (!$dateStr) return '—';
    try {
        $d = new DateTimeImmutable($dateStr);
        return $d->format('d/m/Y');
    } catch (\Throwable) {
        return $dateStr;
    }
}

function fmt_datetime(string $dateStr): string
{
    if (!$dateStr) return '—';
    try {
        $d = new DateTimeImmutable($dateStr);
        return $d->format('d/m/Y H:i');
    } catch (\Throwable) {
        return $dateStr;
    }
}

function fmt_bytes(int $bytes): string
{
    if ($bytes < 1024)        return $bytes . ' B';
    if ($bytes < 1048576)     return round($bytes / 1024, 1) . ' KB';
    if ($bytes < 1073741824)  return round($bytes / 1048576, 1) . ' MB';
    return round($bytes / 1073741824, 2) . ' GB';
}

function time_ago(string $dateStr): string
{
    if (!$dateStr) return '—';
    try {
        $ts   = (new DateTimeImmutable($dateStr))->getTimestamp();
        $diff = time() - $ts;
        if ($diff < 60)     return 'adesso';
        if ($diff < 3600)   return floor($diff / 60) . ' min fa';
        if ($diff < 86400)  return floor($diff / 3600) . ' ore fa';
        if ($diff < 604800) return floor($diff / 86400) . ' giorni fa';
        return fmt_date($dateStr);
    } catch (\Throwable) {
        return $dateStr;
    }
}

// ── Platform helpers ──────────────────────────────────────────────────────────

const PLATFORMS = ['instagram', 'tiktok', 'facebook'];

function platform_label(string $p): string
{
    return match($p) {
        'instagram' => 'Instagram',
        'tiktok'    => 'TikTok',
        'facebook'  => 'Facebook',
        'youtube'   => 'YouTube',
        default     => ucfirst($p),
    };
}

function platform_icon(string $p): string
{
    return match($p) {
        'instagram' => '📷',
        'tiktok'    => '🎵',
        'facebook'  => '👥',
        'youtube'   => '▶️',
        default     => '🌐',
    };
}

// ── Pagination ────────────────────────────────────────────────────────────────

function paginate(array $items, int $perPage = 20): array
{
    $total  = count($items);
    $page   = max(1, input_int('page', 'GET', 1));
    $pages  = max(1, (int)ceil($total / $perPage));
    $page   = min($page, $pages);
    $offset = ($page - 1) * $perPage;
    $slice  = array_slice($items, $offset, $perPage);

    return [
        'items'    => $slice,
        'page'     => $page,
        'pages'    => $pages,
        'total'    => $total,
        'per_page' => $perPage,
        'offset'   => $offset,
    ];
}

// ── Logging ───────────────────────────────────────────────────────────────────

function cw_log(string $level, string $message, array $context = []): void
{
    $logsPath = CW_DATA . '/logs';
    if (!is_dir($logsPath)) mkdir($logsPath, 0750, true);

    $file    = $logsPath . '/' . date('Y-m') . '.log';
    $ctx     = $context ? ' ' . json_encode($context, JSON_UNESCAPED_UNICODE) : '';
    $line    = date('Y-m-d H:i:s') . ' [' . strtoupper($level) . '] '
             . redact_secrets($message . $ctx) . PHP_EOL;

    file_put_contents($file, $line, FILE_APPEND | LOCK_EX);

    // Rotate: keep last 6 months of log files
    $old = glob($logsPath . '/*.log');
    if ($old && count($old) > 6) {
        sort($old);
        unlink($old[0]);
    }
}

// ── Directory size ────────────────────────────────────────────────────────────

function dir_size(string $path): int
{
    $size = 0;
    if (!is_dir($path)) return 0;
    foreach (new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path, FilesystemIterator::SKIP_DOTS)) as $file) {
        $size += $file->getSize();
    }
    return $size;
}

// ── Currency formatting ───────────────────────────────────────────────────────

function fmt_eur(float $amount): string
{
    if ($amount == 0.0)      return '€ 0,00';
    if (abs($amount) >= 1)   return '€ ' . number_format($amount, 2, ',', '.');
    return '€ ' . number_format($amount, 3, ',', '.'); // importi sotto 1€: 3 decimali
}

// ── Alert labels (v0.5) ───────────────────────────────────────────────────────

function alert_label(string $type): string
{
    return match($type) {
        'engagement_spike' => '📈 Spike engagement',
        'volume_spike'     => '📊 Picco pubblicazioni',
        'follower_jump'    => '👥 Variazione follower',
        'format_change'    => '🎬 Nuovo formato',
        'silence'          => '🔇 Silenzio',
        'new_hashtag'      => '#️⃣ Nuovo hashtag',
        'budget_exceeded'  => '💰 Budget LLM esaurito',
        'job_failed'       => '⚠️ Job fallito',
        default            => $type,
    };
}

// ── Metriche comparative (v0.7) ───────────────────────────────────────────────

/**
 * Calcola KPI comparativi per un competitor in un periodo di giorni.
 * Ritorna metriche aggregate su tutti gli handle (o filtrate per piattaforma).
 */
function comparative_metrics(int $competitorId, int $days, ?string $platform = null): array
{
    $handleFilter = ['competitor_id' => $competitorId];
    if ($platform) $handleFilter['platform'] = $platform;
    $handles = db_find('handles', $handleFilter);
    if (!$handles) {
        return ['followers'=>0,'follower_delta'=>0,'posts'=>0,'engagement'=>0,
                'avg_er'=>0.0,'post_freq'=>0.0,'has_data'=>false];
    }

    $cutoffTs   = time() - $days * 86400;
    $cutoffDate = date('Y-m-d', $cutoffTs);
    $fromMonth  = date('Y-m', $cutoffTs);
    $toMonth    = date('Y-m');

    $totFollowers = 0; $totDelta = 0; $erSum = 0.0; $erN = 0;
    $totPosts = 0; $totEng = 0;

    foreach ($handles as $h) {
        $hid = (int)$h['_id'];

        // Follower: ultimo valore + delta nel periodo
        $metrics = db_find('metrics_daily', ['handle_id'=>$hid], 0, 0, 'date', 'desc');
        $latestF = (int)($metrics[0]['followers'] ?? 0);
        $totFollowers += $latestF;
        // delta: confronta ultimo con il primo dentro il periodo (confronto per data, non timestamp)
        $inPeriod = array_values(array_filter($metrics, fn($m) => (string)($m['date'] ?? '') >= $cutoffDate));
        if (count($inPeriod) >= 2) {
            // $inPeriod[0] = più recente (desc), end() = più vecchio nel periodo
            $totDelta += (int)$inPeriod[0]['followers'] - (int)end($inPeriod)['followers'];
        }

        // Post nel periodo
        $posts = db_find_partitioned('posts', ['handle_id'=>$hid], 0, 0, 'posted_at', 'desc', $fromMonth, $toMonth);
        $posts = array_filter($posts, fn($p)=>!empty($p['posted_at']) && strtotime((string)$p['posted_at']) >= $cutoffTs);
        foreach ($posts as $p) {
            $totPosts++;
            $e = (int)$p['likes'] + (int)$p['comments'];
            $totEng += $e;
            if ($latestF > 0) { $erSum += ($e / $latestF) * 100; $erN++; }
        }
    }

    return [
        'followers'      => $totFollowers,
        'follower_delta' => $totDelta,
        'posts'          => $totPosts,
        'engagement'     => $totEng,
        'avg_er'         => $erN > 0 ? round($erSum / $erN, 3) : 0.0,
        'post_freq'      => $days > 0 ? round($totPosts / ($days / 7), 1) : 0.0, // post/settimana
        'has_data'       => ($totFollowers > 0 || $totPosts > 0),
    ];
}

/**
 * Serie temporale follower per il grafico multi-linea.
 * Ritorna [{label, data:[{x:date,y:followers}]}] per ogni competitor.
 */
function comparative_timeseries(array $competitors, int $days, ?string $platform = null): array
{
    $cutoff = date('Y-m-d', time() - $days * 86400);
    $series = [];
    foreach ($competitors as $c) {
        $cid = (int)$c['_id'];
        $hf = ['competitor_id'=>$cid];
        if ($platform) $hf['platform'] = $platform;
        $handles = db_find('handles', $hf);

        // Somma follower per data su tutti gli handle del competitor
        $byDate = [];
        foreach ($handles as $h) {
            $metrics = db_find('metrics_daily', ['handle_id'=>(int)$h['_id']]);
            foreach ($metrics as $m) {
                $d = (string)($m['date'] ?? '');
                if ($d < $cutoff) continue;
                $byDate[$d] = ($byDate[$d] ?? 0) + (int)$m['followers'];
            }
        }
        if (!$byDate) continue;
        ksort($byDate);
        $data = [];
        foreach ($byDate as $d => $f) $data[] = ['x'=>$d, 'y'=>$f];
        $series[] = [
            'label'  => (string)$c['name'] . (!empty($c['is_own']) ? ' ⭐' : ''),
            'is_own' => !empty($c['is_own']),
            'data'   => $data,
        ];
    }
    return $series;
}

/**
 * Stima quando partirà il prossimo giro di cron, dall'ultimo heartbeat.
 * Ritorna una stringa leggibile tipo "verso le 14:30" o "a breve".
 * Assume cron ogni 10 minuti (il default del crontab consigliato).
 */
function next_cron_estimate(int $intervalMin = 10): string
{
    $marker = CW_DATA . '/logs/last_cron.txt';
    if (!is_file($marker)) return 'al prossimo giro di cron';
    $last = strtotime((string)file_get_contents($marker));
    if (!$last) return 'al prossimo giro di cron';

    $next = $last + $intervalMin * 60;
    // Se il prossimo è già passato, il cron dovrebbe girare a momenti
    if ($next <= time()) return 'a breve (entro pochi minuti)';
    return 'verso le ' . date('H:i', $next);
}

// ── Aggregazione mensile storica (v1.2) ───────────────────────────────────────

/**
 * Calcola le statistiche di un competitor per UN mese specifico (YYYY-MM).
 * Legge posts e metrics di quel mese. Usato sia per il calcolo on-demand
 * sia per popolare lo store pre-aggregato monthly_stats.
 */
function monthly_stats_compute(int $competitorId, string $yearMonth, ?string $platform = null): array
{
    $hf = ['competitor_id' => $competitorId];
    if ($platform) $hf['platform'] = $platform;
    $handles = db_find('handles', $hf);

    $followersEnd = 0; $followersStart = 0;
    $posts = 0; $eng = 0; $erSum = 0.0; $erN = 0; $interactions = 0;

    foreach ($handles as $h) {
        $hid = (int)$h['_id'];
        // Metriche del mese: primo e ultimo follower count
        $metrics = array_values(array_filter(
            db_find('metrics_daily', ['handle_id' => $hid]),
            fn($m) => str_starts_with((string)($m['date'] ?? ''), $yearMonth)
        ));
        usort($metrics, fn($a, $b) => strcmp((string)$a['date'], (string)$b['date']));
        if ($metrics) {
            $followersStart += (int)$metrics[0]['followers'];
            $followersEnd   += (int)end($metrics)['followers'];
        }
        // Post del mese
        $monthPosts = db_find_partitioned('posts', ['handle_id' => $hid], 0, 0, 'posted_at', 'desc', $yearMonth, $yearMonth);
        $fEnd = $metrics ? (int)end($metrics)['followers'] : 0;
        foreach ($monthPosts as $p) {
            $posts++;
            $e = (int)$p['likes'] + (int)$p['comments']; // engagement "classico" (per ER, coerente con lo storico)
            $eng += $e;
            $interactions += post_interactions($p);       // interazioni totali = like+commenti+views
            if ($fEnd > 0) { $erSum += ($e / $fEnd) * 100; $erN++; }
        }
    }

    return [
        'followers'       => $followersEnd,
        'follower_growth' => $followersEnd - $followersStart,
        'posts'           => $posts,
        'engagement'      => $eng,
        'interactions'    => $interactions,
        'avg_er'          => $erN > 0 ? round($erSum / $erN, 3) : 0.0,
        // Un mese "ha dati" solo se conosciamo i follower reali di fine mese.
        // Senza follower, i confronti (ER, crescita) sarebbero falsati.
        'has_data'        => ($followersEnd > 0),
    ];
}

/**
 * Salva/aggiorna lo snapshot mensile di un competitor in monthly_stats.
 * Idempotente per (competitor_id, year_month, platform).
 */
function monthly_stats_save(int $competitorId, string $yearMonth, ?string $platform = null): void
{
    $stats = monthly_stats_compute($competitorId, $yearMonth, $platform);
    db_upsert('monthly_stats',
        ['competitor_id' => $competitorId, 'year_month' => $yearMonth, 'platform' => $platform ?? 'all'],
        array_merge($stats, ['computed_at' => date('c')])
    );
}

/**
 * Legge la serie storica mensile di un competitor (tutti i mesi disponibili).
 * Se un mese non è pre-aggregato, lo calcola al volo (lazy) e lo salva.
 */
function monthly_stats_series(int $competitorId, ?string $platform = null): array
{
    $plat = $platform ?? 'all';
    $rows = array_filter(
        db_find('monthly_stats', ['competitor_id' => $competitorId, 'platform' => $plat]),
        fn($r) => true
    );
    $byMonth = [];
    foreach ($rows as $r) $byMonth[(string)$r['year_month']] = $r;
    ksort($byMonth);
    return array_values($byMonth);
}

/**
 * Backfill: popola monthly_stats per TUTTI i mesi storici disponibili,
 * leggendo le partizioni di posts esistenti. Idempotente (upsert).
 * Da chiamare una volta dopo l'upgrade, o quando serve ricostruire.
 */
function monthly_stats_backfill(): int
{
    // Trova tutti i mesi che hanno post
    $postsPath = CW_DATA . '/db/posts';
    $months = [];
    if (is_dir($postsPath)) {
        foreach (glob($postsPath . '/[0-9][0-9][0-9][0-9]-[0-9][0-9]', GLOB_ONLYDIR) ?: [] as $d) {
            $months[] = basename($d);
        }
    }
    // Aggiungi anche i mesi presenti in metrics_daily
    foreach (db_find('metrics_daily') as $m) {
        $ym = substr((string)($m['date'] ?? ''), 0, 7);
        if ($ym && !in_array($ym, $months, true)) $months[] = $ym;
    }
    $months = array_unique($months);
    sort($months);

    $competitors = db_find('competitors', ['archived' => false]);
    // Piattaforme attive (per snapshot per-piattaforma, usate dal Confronto)
    $platforms = [];
    foreach (db_find('handles', ['active' => true]) as $hh) $platforms[(string)$hh['platform']] = true;
    $platforms = array_keys($platforms);

    $count = 0;
    foreach ($months as $ym) {
        foreach ($competitors as $c) {
            $cid = (int)$c['_id'];
            monthly_stats_save($cid, $ym);                 // aggregato (tutte le piattaforme)
            foreach ($platforms as $p) {
                monthly_stats_save($cid, $ym, $p);         // per-piattaforma
                $count++;
            }
            $count++;
        }
    }
    return $count;
}

/** Etichetta leggibile per un tipo di job. */
function job_type_label(string $type): string
{
    return match($type) {
        'fetch_handle'      => 'Fetch profilo',
        'fetch_batch_start' => 'Fetch (avvio batch)',
        'fetch_batch_poll'  => 'Fetch (in corso)',
        'monthly_report'    => 'Report mensile',
        'weekly_report'     => 'Report settimanale',
        'cleanup'           => 'Pulizia',
        default             => $type,
    };
}

/**
 * Interazioni totali di un singolo post.
 * DEFINIZIONE: likes + comments + shares + views
 *   - likes:    "Mi piace"/cuori (sempre disponibile)
 *   - comments: commenti (sempre disponibile)
 *   - shares:   condivisioni — disponibili su TikTok e Facebook; su Instagram
 *               NON sono pubbliche, quindi valgono 0.
 *   - views:    visualizzazioni — video/reel (IG/FB) e play count (TikTok); 0 per foto.
 * Questa è l'UNICA definizione usata in tutta l'app per "interazioni".
 * Nota: il mix di metriche disponibili varia per piattaforma, quindi i confronti
 * vanno fatti DENTRO la stessa piattaforma (vedi filtro nel Confronto).
 */
function post_interactions(array $post): int
{
    return (int)($post['likes'] ?? 0)
         + (int)($post['comments'] ?? 0)
         + (int)($post['shares'] ?? 0)
         + (int)($post['views'] ?? 0);
}

// ── Trasparenza fetch (v1.43) ─────────────────────────────────────────────────

/** Ultimo esito di fetch per ogni piattaforma. Ritorna [platform => row]. */
function fetch_log_latest(): array
{
    $rows = db_find('fetch_log', [], 0, 0, 'finished_at', 'desc');
    $byPlat = [];
    foreach ($rows as $r) {
        $p = (string)($r['platform'] ?? '');
        if ($p && !isset($byPlat[$p])) $byPlat[$p] = $r;
    }
    return $byPlat;
}

/** Esito di fetch più recente in assoluto (qualsiasi piattaforma), o null. */
function fetch_log_most_recent(): ?array
{
    $rows = db_find('fetch_log', [], 1, 0, 'finished_at', 'desc');
    return $rows[0] ?? null;
}

/** Conta i post raccolti (per posted_at) negli ultimi $days giorni. */
function posts_collected_since(int $days = 7): int
{
    $cutoff = date('Y-m-d', time() - $days * 86400);
    $fromMonth = date('Y-m', time() - $days * 86400);
    $toMonth = date('Y-m');
    $posts = db_find_partitioned('posts', [], 0, 0, 'posted_at', 'desc', $fromMonth, $toMonth);
    $n = 0;
    foreach ($posts as $p) {
        if (substr((string)($p['posted_at'] ?? ''), 0, 10) >= $cutoff) $n++;
    }
    return $n;
}

/**
 * Stato di freschezza di un dato in base alla sua età.
 * Ritorna ['class'=>css, 'label'=>testo] per il badge.
 */
function freshness_badge(?string $isoDate): array
{
    if (!$isoDate) return ['class' => 'stale', 'label' => 'mai'];
    $ts = strtotime($isoDate);
    if ($ts === false) return ['class' => 'stale', 'label' => '—'];
    $ageH = (time() - $ts) / 3600;
    if ($ageH < 48)  return ['class' => 'fresh', 'label' => time_ago($isoDate)];
    if ($ageH < 168) return ['class' => 'aging', 'label' => time_ago($isoDate)];
    return ['class' => 'stale', 'label' => time_ago($isoDate)];
}
