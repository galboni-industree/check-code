<?php
declare(strict_types=1);

/**
 * CompetitorWatch — Security Layer
 *
 * - Output escaping
 * - CSRF tokens
 * - Secret redaction for logs
 * - Input sanitization
 * - Rate limiting via file store
 * - Prompt injection mitigation
 */

// ── Output escaping ──────────────────────────────────────────────────────────

/**
 * HTML-escape a value for safe output in templates.
 * Always use this in views: <?= e($variable) ?>
 */
function e(mixed $val): string
{
    return htmlspecialchars((string)$val, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/**
 * Output a value as JSON inside a <script> tag safely.
 * No need for e() here — use only for JS data blocks.
 */
function json_for_js(mixed $val): string
{
    return json_encode($val, JSON_HEX_TAG | JSON_HEX_APOS | JSON_HEX_AMP | JSON_HEX_QUOT | JSON_UNESCAPED_UNICODE);
}

// ── CSRF ─────────────────────────────────────────────────────────────────────

/**
 * Get (or create) the CSRF token for this session.
 */
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token']) || empty($_SESSION['csrf_token_ts'])) {
        regenerate_csrf();
    }

    $lifetime = (int)($GLOBALS['cw_config']['security']['csrf_token_lifetime'] ?? 1800);
    if ((time() - (int)$_SESSION['csrf_token_ts']) > $lifetime) {
        regenerate_csrf();
    }

    return $_SESSION['csrf_token'];
}

function regenerate_csrf(): void
{
    $_SESSION['csrf_token']    = bin2hex(random_bytes(32));
    $_SESSION['csrf_token_ts'] = time();
}

/**
 * Emit a hidden CSRF input field.
 */
function csrf_field(): string
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

/**
 * Verify CSRF token from POST. Exits with 403 on failure.
 */
function csrf_verify(): void
{
    $submitted = $_POST['csrf_token'] ?? '';
    $expected  = $_SESSION['csrf_token'] ?? '';

    if (!$expected || !hash_equals($expected, $submitted)) {
        http_response_code(403);
        exit('<h1>403 — Token CSRF non valido</h1><p>Ricarica la pagina e riprova.</p>');
    }
    // Rotate after use
    regenerate_csrf();
}

// ── Secret redaction ─────────────────────────────────────────────────────────

/** Patterns that look like API keys / secrets */
const SECRET_PATTERNS = [
    '/sk-ant-[A-Za-z0-9\-_]{20,}/i',   // Anthropic
    '/sk-[A-Za-z0-9]{20,}/i',           // OpenAI
    '/AIza[A-Za-z0-9\-_]{30,}/i',       // Google
    '/Bearer\s+[A-Za-z0-9\-_.]{20,}/i', // Generic bearer
    '/apify_api_[A-Za-z0-9]{20,}/i',    // Apify
    '/"api_key"\s*:\s*"[^"]{8,}"/i',    // JSON key field
    '/"key"\s*:\s*"[^"]{8,}"/i',
];

/**
 * Remove secrets from a string before logging.
 */
function redact_secrets(string $text): string
{
    foreach (SECRET_PATTERNS as $pattern) {
        $text = preg_replace($pattern, '[REDACTED]', $text) ?? $text;
    }
    return $text;
}

// ── Input sanitization ───────────────────────────────────────────────────────

/**
 * Get a sanitized string from POST/GET, with max length.
 */
function input_str(string $key, string $source = 'POST', int $maxlen = 255): string
{
    $raw = ($source === 'POST' ? $_POST : $_GET)[$key] ?? '';
    return mb_substr(trim((string)$raw), 0, $maxlen);
}

function input_int(string $key, string $source = 'POST', int $default = 0): int
{
    $raw = ($source === 'POST' ? $_POST : $_GET)[$key] ?? $default;
    return (int)$raw;
}

/**
 * Validate a social media handle. Returns cleaned handle or empty string.
 */
function validate_handle(string $handle): string
{
    // Strip leading @ or URL noise
    $handle = trim($handle);
    // Extract last path segment if URL pasted
    if (str_contains($handle, '/')) {
        $parts  = explode('/', rtrim($handle, '/'));
        $handle = end($parts);
    }
    $handle = ltrim($handle, '@');
    // Allow only safe characters
    if (!preg_match('/^[A-Za-z0-9._\-]{1,100}$/', $handle)) {
        return '';
    }
    return $handle;
}

// ── Prompt injection mitigation ──────────────────────────────────────────────

/**
 * Wrap external (user-sourced) content before sending to LLM.
 * Prevents instruction injection via competitor post text.
 */
function wrap_external_content(string $content): string
{
    // Strip suspicious patterns from content before wrapping
    $content = preg_replace(
        '/\b(ignore|forget|disregard)\b.{0,60}(previous|above|instructions|prompt)/i',
        '[contenuto rimosso per sicurezza]',
        $content
    ) ?? $content;

    return "<external_content>\n" . $content . "\n</external_content>";
}

// ── Rate limiting ────────────────────────────────────────────────────────────

/**
 * Simple IP-based rate limiter stored in data/db/ratelimit/.
 * Returns true if request is allowed, false if blocked.
 * $action = identifier (e.g. 'login'), $max = max attempts, $window = seconds
 */
function rate_limit_check(string $action, int $max = 5, int $window = 900): bool
{
    $ip      = hash('sha256', $_SERVER['REMOTE_ADDR'] ?? 'unknown'); // hash for privacy
    $store   = 'ratelimit';
    $key     = $action . '_' . $ip;
    $records = db_find($store, ['key' => $key], 1);

    $now = time();

    if (!$records) {
        db_insert($store, ['key' => $key, 'attempts' => 1, 'window_start' => $now]);
        return true;
    }

    $r = $records[0];
    $windowStart = (int)($r['window_start'] ?? $now);

    // Reset window if expired
    if (($now - $windowStart) > $window) {
        db_update($store, (int)$r['_id'], ['attempts' => 1, 'window_start' => $now]);
        return true;
    }

    $attempts = (int)($r['attempts'] ?? 1);
    if ($attempts >= $max) {
        return false;
    }

    db_update($store, (int)$r['_id'], ['attempts' => $attempts + 1]);
    return true;
}

// ── Flash messages ───────────────────────────────────────────────────────────

function flash_set(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'message' => $message];
}

function flash_get(): array
{
    $msgs = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $msgs;
}

// ── Redirect helper ──────────────────────────────────────────────────────────

function redirect(string $url, int $code = 302): never
{
    // Only allow relative URLs to prevent open redirect
    if (str_starts_with($url, 'http://') || str_starts_with($url, 'https://')) {
        $appUrl = trim((string)($GLOBALS['cw_config']['app_url'] ?? ''));
        // Se app_url non è configurato, rifiuta QUALSIASI URL assoluto (no open redirect)
        if ($appUrl === '' || !str_starts_with($url, $appUrl)) {
            $url = 'index.php'; // fallback to home
        }
    }

    // Se qualcosa ha già stampato (es. un warning PHP), svuota il buffer
    // così l'header Location può ancora partire ed evitare lo schermo bianco.
    if (!headers_sent()) {
        while (ob_get_level() > 0) ob_end_clean();
        http_response_code($code);
        header('Location: ' . $url);
        exit;
    }

    // Header già inviati: ripiego su redirect lato client (niente schermo bianco)
    $safe = htmlspecialchars($url, ENT_QUOTES);
    echo "<script>location.replace('{$safe}');</script>";
    echo "<noscript><meta http-equiv=\"refresh\" content=\"0;url={$safe}\"></noscript>";
    exit;
}

// ── Audit log ────────────────────────────────────────────────────────────────

function audit_log(string $action, string $detail = ''): void
{
    // Append-only JSONL: one line per event, atomic with LOCK_EX.
    $dir = CW_DATA . '/db/audit';
    if (!is_dir($dir)) mkdir($dir, 0750, true);

    $entry = [
        'ts'     => date('c'),
        'user'   => current_user(),
        'ip'     => hash('sha256', $_SERVER['REMOTE_ADDR'] ?? 'cli'),
        'action' => $action,
        'detail' => mb_substr(redact_secrets($detail), 0, 500),
    ];
    $line = json_encode($entry, JSON_UNESCAPED_UNICODE) . PHP_EOL;
    file_put_contents($dir . '/' . date('Y-m') . '.jsonl', $line, FILE_APPEND | LOCK_EX);
}

/**
 * Read audit entries for a month (most recent first).
 */
function audit_read(string $month, int $limit = 100): array
{
    $file = CW_DATA . '/db/audit/' . $month . '.jsonl';
    if (!file_exists($file)) return [];
    $lines = file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [];
    $lines = array_slice(array_reverse($lines), 0, $limit);
    $out = [];
    foreach ($lines as $l) {
        $e = json_decode($l, true);
        if (is_array($e)) $out[] = $e;
    }
    return $out;
}
