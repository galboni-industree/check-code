<?php
declare(strict_types=1);

/**
 * CompetitorWatch — LLM Router
 *
 * Routes requests to Claude → OpenAI → Gemini with automatic fallback.
 * Tracks costs, enforces monthly budget cap, deduplicates alerts.
 *
 * Pricing (USD, May 2026 — update in config if changed):
 *   Claude claude-opus-4-6:   input $5/M,  output $25/M
 *   OpenAI gpt-4o:            input $2.5/M, output $10/M
 *   Gemini gemini-1.5-pro:    input $3.5/M, output $10.5/M
 */

const LLM_PRICING = [
    'claude' => ['input' => 5.00,  'output' => 25.00],
    'openai' => ['input' => 2.50,  'output' => 10.00],
    'gemini' => ['input' => 3.50,  'output' => 10.50],
];

const USD_TO_EUR = 0.92;

// ── Public API ────────────────────────────────────────────────────────────────

/**
 * Send a prompt to the configured LLM with automatic fallback.
 *
 * @param string $prompt      The full prompt text
 * @param string $system      System message
 * @param int    $max_tokens  Max output tokens
 * @return array ['text' => string, 'model' => string, 'cost_eur' => float, 'error' => string|null]
 */
function llm_complete(string $prompt, string $system = '', int $max_tokens = 2000): array
{
    // Interruttore globale: se le chiamate LLM sono sospese, non spendere nulla.
    if (!config('llm.enabled', true)) {
        return ['text' => '', 'model' => 'disabled', 'cost_eur' => 0,
                'error' => 'Chiamate LLM sospese (riattivabili da Impostazioni)'];
    }

    // Budget check
    if (!llm_budget_ok()) {
        llm_alert_budget_exceeded();
        return ['text' => '', 'model' => 'none', 'cost_eur' => 0, 'error' => 'Budget mensile LLM esaurito'];
    }

    $primary   = config('llm.primary', 'claude');
    $fallbacks = config('llm.fallback', ['openai', 'gemini']);
    $order     = array_merge([$primary], $fallbacks);
    $order     = array_unique($order);

    $lastError = '';
    foreach ($order as $model) {
        $key = config("llm.keys.{$model}", '');
        if (!$key || $key === 'YOUR_KEY_HERE') {
            cw_log('debug', "LLM {$model}: chiave non configurata, skip");
            continue;
        }

        $result = match($model) {
            'claude' => llm_call_claude($prompt, $system, $max_tokens, $key),
            'openai' => llm_call_openai($prompt, $system, $max_tokens, $key),
            'gemini' => llm_call_gemini($prompt, $system, $max_tokens, $key),
            default  => ['text' => '', 'tokens_in' => 0, 'tokens_out' => 0, 'error' => 'Modello sconosciuto'],
        };

        if (!empty($result['error'])) {
            $lastError = $result['error'];
            cw_log('warning', "LLM {$model} fallito: {$lastError}");
            continue;
        }

        // Success — log cost
        $cost = llm_calc_cost($model, (int)$result['tokens_in'], (int)$result['tokens_out']);
        llm_log_call($model, (int)$result['tokens_in'], (int)$result['tokens_out'], $cost, true, '');

        cw_log('info', "LLM {$model} OK — {$result['tokens_in']}in/{$result['tokens_out']}out — " . fmt_eur($cost));

        return [
            'text'     => $result['text'],
            'model'    => $model,
            'cost_eur' => $cost,
            'error'    => null,
        ];
    }

    cw_log('error', "LLM tutti i modelli falliti. Ultimo errore: {$lastError}");
    return ['text' => '', 'model' => 'none', 'cost_eur' => 0, 'error' => $lastError ?: 'Tutti i modelli LLM falliti'];
}

// ── Provider calls ────────────────────────────────────────────────────────────

function llm_call_claude(string $prompt, string $system, int $max_tokens, string $key): array
{
    $payload = [
        'model'      => 'claude-opus-4-6',
        'max_tokens' => $max_tokens,
        'messages'   => [['role' => 'user', 'content' => $prompt]],
    ];
    if ($system) $payload['system'] = $system;

    $response = llm_http_post(
        'https://api.anthropic.com/v1/messages',
        $payload,
        [
            'x-api-key: ' . $key,
            'anthropic-version: 2023-06-01',
            'content-type: application/json',
        ]
    );

    if (!$response['ok']) {
        return ['text' => '', 'tokens_in' => 0, 'tokens_out' => 0, 'error' => $response['error']];
    }

    $data = $response['data'];
    if (isset($data['error'])) {
        return ['text' => '', 'tokens_in' => 0, 'tokens_out' => 0, 'error' => $data['error']['message'] ?? 'Claude error'];
    }

    return [
        'text'       => $data['content'][0]['text'] ?? '',
        'tokens_in'  => $data['usage']['input_tokens'] ?? 0,
        'tokens_out' => $data['usage']['output_tokens'] ?? 0,
        'error'      => '',
    ];
}

function llm_call_openai(string $prompt, string $system, int $max_tokens, string $key): array
{
    $messages = [];
    if ($system) $messages[] = ['role' => 'system', 'content' => $system];
    $messages[] = ['role' => 'user', 'content' => $prompt];

    $payload = [
        'model'      => 'gpt-4o',
        'max_tokens' => $max_tokens,
        'messages'   => $messages,
    ];

    $response = llm_http_post(
        'https://api.openai.com/v1/chat/completions',
        $payload,
        [
            'Authorization: Bearer ' . $key,
            'content-type: application/json',
        ]
    );

    if (!$response['ok']) {
        return ['text' => '', 'tokens_in' => 0, 'tokens_out' => 0, 'error' => $response['error']];
    }

    $data = $response['data'];
    if (isset($data['error'])) {
        return ['text' => '', 'tokens_in' => 0, 'tokens_out' => 0, 'error' => $data['error']['message'] ?? 'OpenAI error'];
    }

    return [
        'text'       => $data['choices'][0]['message']['content'] ?? '',
        'tokens_in'  => $data['usage']['prompt_tokens'] ?? 0,
        'tokens_out' => $data['usage']['completion_tokens'] ?? 0,
        'error'      => '',
    ];
}

function llm_call_gemini(string $prompt, string $system, int $max_tokens, string $key): array
{
    $parts = [];
    if ($system) $parts[] = ['text' => "System: {$system}\n\n"];
    $parts[] = ['text' => $prompt];

    $payload = [
        'contents'         => [['role' => 'user', 'parts' => $parts]],
        'generationConfig' => ['maxOutputTokens' => $max_tokens],
    ];

    // Chiave nell'header x-goog-api-key (non in query string: evita esposizione nei log)
    $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent';

    $response = llm_http_post($url, $payload, ['content-type: application/json', 'x-goog-api-key: ' . $key]);

    if (!$response['ok']) {
        return ['text' => '', 'tokens_in' => 0, 'tokens_out' => 0, 'error' => $response['error']];
    }

    $data = $response['data'];
    if (isset($data['error'])) {
        return ['text' => '', 'tokens_in' => 0, 'tokens_out' => 0, 'error' => $data['error']['message'] ?? 'Gemini error'];
    }

    $text    = $data['candidates'][0]['content']['parts'][0]['text'] ?? '';
    $usage   = $data['usageMetadata'] ?? [];

    return [
        'text'       => $text,
        'tokens_in'  => $usage['promptTokenCount'] ?? 0,
        'tokens_out' => $usage['candidatesTokenCount'] ?? 0,
        'error'      => '',
    ];
}

// ── HTTP helper ───────────────────────────────────────────────────────────────

function llm_http_post(string $url, array $payload, array $headers): array
{
    if (!function_exists('curl_init')) {
        return ['ok' => false, 'data' => [], 'error' => 'cURL non disponibile'];
    }

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($payload),
        CURLOPT_HTTPHEADER     => $headers,
        CURLOPT_TIMEOUT        => 90,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);

    $body  = curl_exec($ch);
    $errno = curl_errno($ch);
    $err   = curl_error($ch);
    $code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($errno || $body === false) {
        return ['ok' => false, 'data' => [], 'error' => "cURL error {$errno}: {$err}"];
    }

    $data = json_decode($body, true);
    if (!is_array($data)) {
        return ['ok' => false, 'data' => [], 'error' => "Risposta non JSON (HTTP {$code})"];
    }

    if ($code >= 400) {
        $msg = $data['error']['message'] ?? $data['error'] ?? "HTTP {$code}";
        return ['ok' => false, 'data' => $data, 'error' => (string)$msg];
    }

    return ['ok' => true, 'data' => $data, 'error' => ''];
}

// ── Budget & cost ─────────────────────────────────────────────────────────────

function llm_calc_cost(string $model, int $tokens_in, int $tokens_out): float
{
    $pricing = LLM_PRICING[$model] ?? ['input' => 5.0, 'output' => 25.0];
    $usd     = ($tokens_in / 1_000_000 * $pricing['input'])
             + ($tokens_out / 1_000_000 * $pricing['output']);
    return round($usd * USD_TO_EUR, 6);
}

function llm_monthly_spent(): float
{
    $month = date('Y-m');
    $logs  = db_find('llm_calls', ['month' => $month]);
    return array_sum(array_column($logs, 'cost_eur'));
}

function llm_budget_ok(): bool
{
    $budget = (float)config('llm.budget_eur_monthly', 30);
    return llm_monthly_spent() < $budget;
}

function llm_log_call(string $model, int $in, int $out, float $cost, bool $ok, string $error): void
{
    db_insert('llm_calls', [
        'model'     => $model,
        'tokens_in' => $in,
        'tokens_out'=> $out,
        'cost_eur'  => $cost,
        'success'   => $ok,
        'error'     => mb_substr(redact_secrets($error), 0, 200),
        'month'     => date('Y-m'),
        'called_at' => date('c'),
    ]);
}

function llm_alert_budget_exceeded(): void
{
    // Deduplicate: max one alert per day
    $today = date('Y-m-d');
    $exists = db_find('alerts', ['type' => 'budget_exceeded', 'date' => $today], 1);
    if ($exists) return;

    $spent  = llm_monthly_spent();
    $budget = (float)config('llm.budget_eur_monthly', 30);
    db_insert('alerts', [
        'type'    => 'budget_exceeded',
        'date'    => $today,
        'message' => sprintf('Budget LLM mensile esaurito: spesi %s su %s', fmt_eur($spent), fmt_eur($budget)),
        'read'    => false,
    ]);
}

// ── Health check ──────────────────────────────────────────────────────────────

/**
 * Quick probe of each configured LLM. Returns status per provider.
 */
function llm_health_check(): array
{
    $results = [];
    foreach (['claude', 'openai', 'gemini'] as $model) {
        $key = config("llm.keys.{$model}", '');
        if (!$key || $key === 'YOUR_KEY_HERE') {
            $results[$model] = ['ok' => false, 'error' => 'Chiave non configurata'];
            continue;
        }

        $probe = match($model) {
            'claude' => llm_call_claude('Rispondi solo con: ok', '', 10, $key),
            'openai' => llm_call_openai('Rispondi solo con: ok', '', 10, $key),
            'gemini' => llm_call_gemini('Rispondi solo con: ok', '', 10, $key),
            default  => ['error' => 'unknown'],
        };

        $results[$model] = [
            'ok'    => empty($probe['error']),
            'error' => $probe['error'] ?? '',
        ];
    }
    return $results;
}
