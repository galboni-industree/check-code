<?php
declare(strict_types=1);

/**
 * CompetitorWatch — Data Providers (v0.3: SOLO APIFY)
 *
 * Tutti i dati social passano attraverso Apify.
 * Le chiamate dirette alle API ufficiali dei social sono state
 * rimosse/commentate su richiesta (vedi fondo file per YouTube Data API).
 *
 * Actor di default (override in config['apify']['actors']):
 *   instagram → apify~instagram-profile-scraper  (profilo + ultimi post)
 *   facebook  → apify~facebook-pages-scraper     (pagina + post)
 *   youtube   → streamers~youtube-scraper        (canale + video)
 *
 * Endpoint: run-sync-get-dataset-items (sincrono).
 * Con i limiti del progetto (max 10 competitor, ~12 item per fetch)
 * resta sotto il timeout di 60s. Timeout gestito esplicitamente.
 */

// ── Cost tracking ─────────────────────────────────────────────────────────────

/** Prezzi indicativi USD per 1000 risultati (override in config['apify']['prices']) */
const APIFY_DEFAULT_PRICES = [
    'instagram' => 1.60,
    'tiktok'    => 5.00,  // clockworks/tiktok-profile-scraper: $5/1000 risultati
    'facebook'  => 2.00,
    'youtube'   => 2.40,
];

function apify_log_call(string $platform, int $items, bool $ok): void
{
    $prices = config('apify.prices', APIFY_DEFAULT_PRICES);
    $perK   = (float)($prices[$platform] ?? 2.0);
    $cost   = round(($items / 1000) * $perK * USD_TO_EUR, 6);

    db_insert('apify_calls', [
        'platform'  => $platform,
        'items'     => $items,
        'cost_eur'  => $cost,
        'success'   => $ok,
        'month'     => date('Y-m'),
        'called_at' => date('c'),
    ]);
}

function apify_monthly_spent(): float
{
    $calls = db_find('apify_calls', ['month' => date('Y-m')]);
    return array_sum(array_column($calls, 'cost_eur'));
}

// ── Metadata enrichment (gratis: derivata dal payload già pagato) ────────────

/**
 * Extract hashtags, mentions, and temporal features from a post.
 */
function enrich_post_meta(string $text, ?string $postedAt): array
{
    preg_match_all('/#([\p{L}\p{N}_]{2,50})/u', $text, $hm);
    preg_match_all('/@([A-Za-z0-9._]{1,48}[A-Za-z0-9_])/u', $text, $mm);

    $hour = null; $weekday = null;
    if ($postedAt) {
        try {
            $d = new DateTimeImmutable($postedAt);
            $d = $d->setTimezone(new DateTimeZone(config('timezone', 'Europe/Rome')));
            $hour    = (int)$d->format('G');
            $weekday = (int)$d->format('N'); // 1=lun … 7=dom
        } catch (\Throwable) {}
    }

    return [
        'hashtags'   => array_slice(array_unique(array_map('mb_strtolower', $hm[1])), 0, 20),
        'mentions'   => array_slice(array_unique($mm[1]), 0, 10),
        'text_len'   => mb_strlen($text),
        'hour'       => $hour,
        'weekday'    => $weekday,
        'has_question' => str_contains($text, '?'),
        'emoji_count'  => preg_match_all('/[\x{1F300}-\x{1FAFF}\x{2600}-\x{27BF}]/u', $text) ?: 0,
    ];
}

// ── Entry point ───────────────────────────────────────────────────────────────

/**
 * Fetch data for a handle record. Returns ['ok' => bool, 'error' => string, 'posts' => int]
 */
function provider_fetch_handle(array $handle): array
{
    $platform = $handle['platform'] ?? '';
    $token    = (string)config('apify.token', '');

    if (!$token || $token === 'YOUR_APIFY_TOKEN') {
        return ['ok' => false, 'error' => 'Token Apify non configurato (settings)', 'posts' => 0];
    }
    if (!in_array($platform, PLATFORMS, true)) {
        return ['ok' => false, 'error' => "Piattaforma non supportata: {$platform}", 'posts' => 0];
    }

    return apify_fetch($handle, $token);
}

// ── Apify ─────────────────────────────────────────────────────────────────────

function apify_default_actor(string $platform): string
{
    return match($platform) {
        'instagram' => 'apify~instagram-profile-scraper',
        'tiktok'    => 'clockworks~tiktok-profile-scraper',
        'facebook'  => 'apify~facebook-pages-scraper',
        'youtube'   => 'streamers~youtube-scraper',
        default     => '',
    };
}

function apify_build_input(string $platform, string $handleName, int $maxItems): array
{
    return match($platform) {
        'instagram' => [
            'usernames'    => [$handleName],
            'resultsLimit' => $maxItems,
        ],
        'tiktok' => [
            'profiles'             => [$handleName],
            'resultsPerPage'       => $maxItems,
            'shouldDownloadVideos' => false,
            'shouldDownloadCovers' => false,
        ],
        'facebook' => [
            'startUrls'    => [['url' => 'https://www.facebook.com/' . $handleName]],
            'resultsLimit' => $maxItems,
        ],
        'youtube' => [
            'startUrls'      => [['url' => 'https://www.youtube.com/@' . $handleName]],
            'maxResults'     => $maxItems,
            'maxResultsShorts' => 0,
            'maxResultStreams' => 0,
        ],
        default => [],
    };
}

function apify_fetch(array $handle, string $token): array
{
    $platform   = $handle['platform'];
    $handleName = $handle['handle'];
    $maxItems   = (int)config('apify.max_items_per_fetch', 12);

    $actor = (string)config("apify.actors.{$platform}", apify_default_actor($platform));
    if (!$actor) {
        return ['ok' => false, 'error' => "Nessun actor configurato per {$platform}", 'posts' => 0];
    }

    $input = apify_build_input($platform, $handleName, $maxItems);

    $url = sprintf(
        'https://api.apify.com/v2/acts/%s/run-sync-get-dataset-items?timeout=55&memory=1024',
        rawurlencode($actor)
    );

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($input),
        CURLOPT_HTTPHEADER     => [
            'Authorization: Bearer ' . $token,
            'Content-Type: application/json',
        ],
        CURLOPT_TIMEOUT        => 90,   // > Apify 55s actor timeout
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);

    $body  = curl_exec($ch);
    $errno = curl_errno($ch);
    $err   = curl_error($ch);
    $code  = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($errno === CURLE_OPERATION_TIMEDOUT) {
        return ['ok' => false, 'error' => 'Apify timeout: ridurre max_items_per_fetch in config', 'posts' => 0];
    }
    if ($errno || $body === false) {
        return ['ok' => false, 'error' => "cURL {$errno}: {$err}", 'posts' => 0];
    }
    if ($code === 401 || $code === 403) {
        return ['ok' => false, 'error' => 'Token Apify non valido o scaduto', 'posts' => 0];
    }
    if ($code >= 400) {
        return ['ok' => false, 'error' => "Apify HTTP {$code}: " . mb_substr($body, 0, 200), 'posts' => 0];
    }

    $items = json_decode($body, true);
    if (!is_array($items)) {
        return ['ok' => false, 'error' => 'Risposta Apify non valida', 'posts' => 0];
    }
    if (empty($items)) {
        apify_log_call($platform, 0, false);
        return ['ok' => false, 'error' => 'Apify ha restituito 0 risultati (handle errato o actor in errore?)', 'posts' => 0];
    }

    apify_log_call($platform, count($items), true);

    // Save raw snapshot with dedup hash (stable payload, no timestamps)
    $hash = hash('sha256', json_encode($items));
    provider_save_snapshot($handle, $items, $hash);

    // Normalize per platform
    $normalized = match($platform) {
        'instagram' => apify_normalize_instagram($handle, $items),
        'tiktok'    => apify_normalize_tiktok($handle, $items),
        'facebook'  => apify_normalize_facebook($handle, $items),
        'youtube'   => apify_normalize_youtube($handle, $items),
        default     => ['posts' => 0, 'followers' => null],
    };

    // Save daily metrics if followers found
    if ($normalized['followers'] !== null) {
        provider_save_metrics($handle, $normalized['followers'], $normalized['posts_total'] ?? null);
    }

    return ['ok' => true, 'error' => '', 'posts' => $normalized['posts']];
}

// ── Batch asincrono (v1.3): un run per piattaforma, polling dal cron ──────────

/**
 * Costruisce l'input batch per una piattaforma con PIÙ handle.
 * instagram/facebook supportano liste native; youtube usa startUrls multipli.
 */
function apify_build_batch_input(string $platform, array $handleNames, int $maxItems): array
{
    return match($platform) {
        'instagram' => [
            'usernames'    => array_values($handleNames),
            'resultsLimit' => $maxItems,
        ],
        'tiktok' => [
            'profiles'             => array_values($handleNames),
            'resultsPerPage'       => $maxItems,
            'shouldDownloadVideos' => false,
            'shouldDownloadCovers' => false,
        ],
        'facebook' => [
            'startUrls'    => array_map(fn($h) => ['url' => 'https://www.facebook.com/' . $h], $handleNames),
            'resultsLimit' => $maxItems,
        ],
        'youtube' => [
            'startUrls'        => array_map(fn($h) => ['url' => 'https://www.youtube.com/@' . $h], $handleNames),
            'maxResults'       => $maxItems,
            'maxResultsShorts' => 0,
            'maxResultStreams' => 0,
        ],
        default => [],
    };
}

/**
 * Avvia un run ASINCRONO dell'actor per una piattaforma con tutti gli handle.
 * Ritorna ['ok'=>bool, 'run_id'=>string, 'dataset_id'=>string, 'error'=>string].
 * Non attende il completamento: il polling avviene a un giro di cron successivo.
 */
function apify_start_batch(string $platform, array $handleNames, string $token): array
{
    $maxItems = (int)config('apify.max_items_per_fetch', 12);
    $actor    = (string)config("apify.actors.{$platform}", apify_default_actor($platform));
    if (!$actor)        return ['ok' => false, 'error' => "Nessun actor per {$platform}"];
    if (!$handleNames)  return ['ok' => false, 'error' => 'Nessun handle da elaborare'];

    $input = apify_build_batch_input($platform, $handleNames, $maxItems);

    // Endpoint asincrono: risponde subito con il run object (niente attesa/timeout)
    $url = sprintf('https://api.apify.com/v2/acts/%s/runs?memory=1024', rawurlencode($actor));

    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($input),
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token, 'Content-Type: application/json'],
        CURLOPT_TIMEOUT        => 20,   // solo l'avvio, risponde in ms
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = curl_exec($ch);
    $errno = curl_errno($ch); $err = curl_error($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    if ($errno || $body === false) return ['ok' => false, 'error' => "cURL {$errno}: {$err}"];
    if ($code === 401 || $code === 403) return ['ok' => false, 'error' => 'Token Apify non valido'];
    if ($code >= 400) return ['ok' => false, 'error' => "Apify HTTP {$code}: " . mb_substr((string)$body, 0, 200)];

    $data = json_decode((string)$body, true);
    $run  = $data['data'] ?? null;
    if (!is_array($run) || empty($run['id'])) return ['ok' => false, 'error' => 'Risposta avvio non valida'];

    return [
        'ok' => true, 'error' => '',
        'run_id'     => (string)$run['id'],
        'dataset_id' => (string)($run['defaultDatasetId'] ?? ''),
    ];
}

/**
 * Controlla lo stato di un run. Ritorna lo status Apify:
 * READY|RUNNING|SUCCEEDED|FAILED|TIMED-OUT|ABORTED, o '' su errore di rete.
 */
function apify_run_status(string $runId, string $token): string
{
    $url = sprintf('https://api.apify.com/v2/actor-runs/%s', rawurlencode($runId));
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
        CURLOPT_TIMEOUT        => 20,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($body === false || $code >= 400) return '';
    $data = json_decode((string)$body, true);
    return (string)($data['data']['status'] ?? '');
}

/**
 * Scarica tutti gli item di un dataset.
 * Ritorna array di item, oppure NULL in caso di errore di rete/HTTP
 * (così il chiamante può ritentare invece di scambiarlo per "vuoto").
 */
function apify_fetch_dataset(string $datasetId, string $token): ?array
{
    $url = sprintf('https://api.apify.com/v2/datasets/%s/items?clean=true&format=json', rawurlencode($datasetId));
    $ch = curl_init($url);
    curl_setopt_array($ch, [
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_HTTPHEADER     => ['Authorization: Bearer ' . $token],
        CURLOPT_TIMEOUT        => 60,
        CURLOPT_CONNECTTIMEOUT => 15,
        CURLOPT_SSL_VERIFYPEER => true,
        CURLOPT_SSL_VERIFYHOST => 2,
    ]);
    $body = curl_exec($ch);
    $code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    if ($body === false || $code >= 400) return null;  // errore: ritentabile
    $items = json_decode((string)$body, true);
    return is_array($items) ? $items : null;
}

/**
 * Distribuisce un dataset batch ai singoli handle (fault-tolerant).
 * Ogni item del dataset viene associato all'handle giusto tramite username.
 * Un profilo mancante o malformato NON blocca gli altri.
 * Ritorna ['handled'=>int, 'posts'=>int, 'missing'=>array di handle senza dati].
 */
function apify_distribute_batch(string $platform, array $handles, array $items): array
{
    // Estrae lo username di un item secondo la piattaforma (i campi divergono)
    $usernameOf = static function(array $it) use ($platform): string {
        $raw = match($platform) {
            'tiktok'    => $it['authorMeta']['name'] ?? $it['authorMeta']['uniqueId'] ?? $it['username'] ?? '',
            'facebook'  => $it['pageName'] ?? $it['username'] ?? $it['facebookId'] ?? '',
            'instagram' => $it['username'] ?? $it['ownerUsername'] ?? '',
            default     => $it['username'] ?? $it['userName'] ?? $it['pageName'] ?? $it['channelName'] ?? '',
        };
        return strtolower(trim((string)$raw));
    };

    // Raggruppa gli item per autore in LISTE (TikTok: N video per profilo;
    // IG/FB: tipicamente 1 oggetto profilo, ma il raggruppamento regge entrambi).
    $byUser = [];
    foreach ($items as $it) {
        if (!is_array($it)) continue;
        if (isset($it['errorCode'])) continue; // item di errore (profilo privato/eliminato)
        $u = $usernameOf($it);
        if ($u === '') continue;
        $byUser[$u][] = $it;
    }

    $totalPosts = 0; $handled = 0; $missing = [];
    foreach ($handles as $h) {
        $uname = strtolower(trim((string)$h['handle']));
        $group = $byUser[$uname] ?? null;
        if (!$group) { $missing[] = (string)$h['handle']; continue; }

        try {
            // Passa l'INTERO gruppo di item di quel profilo al normalizer
            $hash = hash('sha256', json_encode($group));
            provider_save_snapshot($h, $group, $hash);
            $norm = match($platform) {
                'instagram' => apify_normalize_instagram($h, $group),
                'tiktok'    => apify_normalize_tiktok($h, $group),
                'facebook'  => apify_normalize_facebook($h, $group),
                'youtube'   => apify_normalize_youtube($h, $group),
                default     => ['posts' => 0, 'followers' => null],
            };
            if (($norm['followers'] ?? null) !== null) {
                provider_save_metrics($h, (int)$norm['followers'], $norm['posts_total'] ?? null);
            }
            $totalPosts += (int)($norm['posts'] ?? 0);
            $handled++;
            if (function_exists('alerts_evaluate_handle')) alerts_evaluate_handle($h);
        } catch (\Throwable $e) {
            cw_log('error', "Batch distribute fallito per @{$h['handle']}: " . $e->getMessage());
            $missing[] = (string)$h['handle'];
        }
    }

    apify_log_call($platform, count($items), $handled > 0);
    return ['handled' => $handled, 'posts' => $totalPosts, 'missing' => $missing];
}

// ── Normalizers ───────────────────────────────────────────────────────────────

/**
 * apify~instagram-profile-scraper output:
 * [{username, followersCount, followsCount, postsCount, latestPosts: [{id, caption, likesCount, commentsCount, timestamp, type, videoViewCount}]}]
 */
function apify_normalize_instagram(array $handle, array $items): array
{
    $profile   = $items[0] ?? [];
    $followers = isset($profile['followersCount']) ? (int)$profile['followersCount'] : null;
    $postsTotal= isset($profile['postsCount']) ? (int)$profile['postsCount'] : null;
    $saved     = 0;

    $latest = $profile['latestPosts'] ?? [];
    // Some actors return posts as top-level items instead
    if (!$latest && isset($items[0]['likesCount'])) {
        $latest = $items;
    }

    foreach ($latest as $p) {
        $extId = (string)($p['id'] ?? $p['shortCode'] ?? '');
        if (!$extId) continue;
        $postedAt = $p['timestamp'] ?? null;
        $saved += provider_save_post($handle, [
            'external_id' => $extId,
            'posted_at'   => $postedAt,
            'text'        => mb_substr((string)($p['caption'] ?? ''), 0, 2000),
            'media_type'  => (string)($p['type'] ?? 'image'),
            'media_urls'  => array_filter([(string)($p['displayUrl'] ?? ''), (string)($p['videoUrl'] ?? '')]),
            'duration_s'  => isset($p['videoDuration']) ? (int)$p['videoDuration'] : null,
            'likes'       => (int)($p['likesCount'] ?? 0),
            'comments'    => (int)($p['commentsCount'] ?? 0),
            'shares'      => 0,
            'views'       => (int)($p['videoViewCount'] ?? 0),
        ]);
    }

    return ['posts' => $saved, 'followers' => $followers, 'posts_total' => $postsTotal];
}

/**
 * clockworks~tiktok-profile-scraper output (un item per video):
 * [{authorMeta: {name, fans, heart, video}, id, text, createTimeISO, diggCount,
 *   shareCount, commentCount, playCount, videoMeta: {duration}, ...}]
 * I follower stanno in authorMeta.fans (ripetuto su ogni video dello stesso autore).
 * TikTok ESPONE le condivisioni (shareCount) e le views (playCount), a differenza di IG.
 */
function apify_normalize_tiktok(array $handle, array $items): array
{
    $followers = null; $postsTotal = null; $saved = 0;

    foreach ($items as $p) {
        if (!is_array($p)) continue;
        // Salta gli item di errore (profilo privato/eliminato): hanno errorCode
        if (isset($p['errorCode'])) continue;

        $author = $p['authorMeta'] ?? [];
        // Follower e totale video dal primo item valido dell'autore
        if ($followers === null && isset($author['fans']))  $followers  = (int)$author['fans'];
        if ($postsTotal === null && isset($author['video'])) $postsTotal = (int)$author['video'];

        $extId = (string)($p['id'] ?? '');
        if (!$extId) continue;
        $postedAt = $p['createTimeISO'] ?? (isset($p['createTime']) ? date('c', (int)$p['createTime']) : null);

        $saved += provider_save_post($handle, [
            'external_id' => $extId,
            'posted_at'   => $postedAt,
            'text'        => mb_substr((string)($p['text'] ?? ''), 0, 2000),
            'media_type'  => 'video', // TikTok è sempre video
            'media_urls'  => array_filter([(string)($p['webVideoUrl'] ?? '')]),
            'duration_s'  => isset($p['videoMeta']['duration']) ? (int)$p['videoMeta']['duration'] : null,
            'likes'       => (int)($p['diggCount'] ?? 0),     // "Mi piace" (cuori)
            'comments'    => (int)($p['commentCount'] ?? 0),
            'shares'      => (int)($p['shareCount'] ?? 0),     // TikTok espone le condivisioni
            'views'       => (int)($p['playCount'] ?? 0),      // play count
        ]);
    }

    return ['posts' => $saved, 'followers' => $followers, 'posts_total' => $postsTotal];
}

/**
 * apify~facebook-pages-scraper output (solo Pagine pubbliche):
 * page info con {followers, likes} + posts con {postId, text, likes, comments, shares, time}
 */
function apify_normalize_facebook(array $handle, array $items): array
{
    $followers = null;
    $saved     = 0;

    foreach ($items as $item) {
        // Page info item
        if (isset($item['followers']) && !isset($item['postId'])) {
            $followers = (int)$item['followers'];
        }
        // Post items (top-level or nested)
        $posts = $item['posts'] ?? (isset($item['postId']) ? [$item] : []);
        foreach ($posts as $p) {
            $extId = (string)($p['postId'] ?? $p['url'] ?? '');
            if (!$extId) continue;
            $mediaUrls = [];
            if (!empty($p['media']) && is_array($p['media'])) {
                foreach (array_slice($p['media'], 0, 5) as $m) {
                    if (is_array($m) && !empty($m['url'])) $mediaUrls[] = (string)$m['url'];
                    elseif (is_string($m)) $mediaUrls[] = $m;
                }
            }
            $saved += provider_save_post($handle, [
                'external_id' => $extId,
                'posted_at'   => $p['time'] ?? $p['date'] ?? null,
                'text'        => mb_substr((string)($p['text'] ?? ''), 0, 2000),
                'media_type'  => !empty($p['isVideo']) ? 'video' : 'post',
                'media_urls'  => $mediaUrls,
                'likes'       => (int)($p['likes'] ?? 0),
                'comments'    => (int)($p['comments'] ?? 0),
                'shares'      => (int)($p['shares'] ?? 0),
                'views'       => (int)($p['viewsCount'] ?? 0),
            ]);
        }
    }

    return ['posts' => $saved, 'followers' => $followers, 'posts_total' => null];
}

/**
 * streamers~youtube-scraper output:
 * [{id, title, viewCount, likes, commentsCount, date, channelName, numberOfSubscribers, ...}]
 */
function apify_normalize_youtube(array $handle, array $items): array
{
    $followers = null;
    $saved     = 0;

    foreach ($items as $v) {
        if ($followers === null && isset($v['numberOfSubscribers'])) {
            $followers = (int)$v['numberOfSubscribers'];
        }
        $extId = (string)($v['id'] ?? $v['url'] ?? '');
        if (!$extId) continue;
        // Title + description = richer text payload for the LLM
        $text = trim((string)($v['title'] ?? '') . "\n" . mb_substr((string)($v['text'] ?? $v['description'] ?? ''), 0, 800));
        $saved += provider_save_post($handle, [
            'external_id' => $extId,
            'posted_at'   => $v['date'] ?? null,
            'text'        => mb_substr($text, 0, 2000),
            'media_type'  => 'video',
            'media_urls'  => array_filter([(string)($v['thumbnailUrl'] ?? '')]),
            'duration_s'  => isset($v['duration']) ? (int)$v['duration'] : null,
            'likes'       => (int)($v['likes'] ?? 0),
            'comments'    => (int)($v['commentsCount'] ?? 0),
            'shares'      => 0,
            'views'       => (int)($v['viewCount'] ?? 0),
        ]);
    }

    return ['posts' => $saved, 'followers' => $followers, 'posts_total' => null];
}

// ── Persistence helpers ───────────────────────────────────────────────────────

/**
 * Save a post if not already present (dedup by handle+external_id).
 * Updates metrics if already present. Returns 1 if new, 0 if updated/skipped.
 */
function provider_save_post(array $handle, array $post): int
{
    $handleId = (int)$handle['_id'];
    $extId    = $post['external_id'];

    // Determine partition from posted_at, fallback current month
    $partition = date('Y-m');
    if (!empty($post['posted_at'])) {
        try {
            $partition = (new DateTimeImmutable((string)$post['posted_at']))->format('Y-m');
        } catch (\Throwable) { /* keep current */ }
    }

    // Dedup: search in target partition
    $existing = db_find_partitioned('posts',
        ['handle_id' => $handleId, 'external_id' => $extId],
        1, 0, '_id', 'desc', $partition, $partition
    );

    $meta = enrich_post_meta((string)$post['text'], $post['posted_at'] ?? null);

    $record = [
        'handle_id'     => $handleId,
        'competitor_id' => (int)$handle['competitor_id'],
        'platform'      => $handle['platform'],
        'external_id'   => $extId,
        'posted_at'     => $post['posted_at'],
        'text'          => $post['text'],
        'media_type'    => $post['media_type'],
        'media_urls'    => array_slice((array)($post['media_urls'] ?? []), 0, 5),
        'duration_s'    => $post['duration_s'] ?? null,
        'likes'         => $post['likes'],
        'comments'      => $post['comments'],
        'shares'        => $post['shares'],
        'views'         => $post['views'],
        'hashtags'      => $meta['hashtags'],
        'mentions'      => $meta['mentions'],
        'text_len'      => $meta['text_len'],
        'hour'          => $meta['hour'],
        'weekday'       => $meta['weekday'],
        'has_question'  => $meta['has_question'],
        'emoji_count'   => $meta['emoji_count'],
    ];

    if ($existing) {
        // Update engagement metrics (they grow over time)
        db_update_partitioned('posts',
            ['handle_id' => $handleId, 'external_id' => $extId],
            ['likes' => $post['likes'], 'comments' => $post['comments'],
             'shares' => $post['shares'], 'views' => $post['views']]
        );
        return 0;
    }

    db_insert_partitioned('posts', $partition, $record);
    return 1;
}

/**
 * Save daily follower metrics (one record per handle per day, upsert).
 */
function provider_save_metrics(array $handle, int $followers, ?int $postsTotal): void
{
    db_upsert('metrics_daily',
        ['handle_id' => (int)$handle['_id'], 'date' => date('Y-m-d')],
        [
            'competitor_id' => (int)$handle['competitor_id'],
            'platform'      => $handle['platform'],
            'followers'     => $followers,
            'posts_total'   => $postsTotal,
        ]
    );
}

/**
 * Save raw snapshot with dedup: skip if identical hash exists for this handle.
 */
function provider_save_snapshot(array $handle, array $payload, string $hash): void
{
    if (db_exists('snapshots_index', ['handle_id' => (int)$handle['_id'], 'hash' => $hash])) {
        return; // identical data already stored
    }

    $dir = CW_DATA . '/snapshots/' . date('Y-m');
    if (!is_dir($dir)) mkdir($dir, 0750, true);

    $file = sprintf('%s/h%d_%s.json', $dir, (int)$handle['_id'], substr($hash, 0, 12));
    file_put_contents($file, json_encode($payload, JSON_UNESCAPED_UNICODE), LOCK_EX);

    db_insert('snapshots_index', [
        'handle_id' => (int)$handle['_id'],
        'hash'      => $hash,
        'file'      => basename($file),
        'month'     => date('Y-m'),
    ]);
}

// ── Manual input (non è una API social: resta disponibile come fallback) ────

/**
 * Save manually-entered metrics from the competitors page form.
 */
function provider_manual_metrics(array $handle, int $followers, ?int $postsTotal): void
{
    provider_save_metrics($handle, $followers, $postsTotal);
    audit_log('manual_metrics', "handle {$handle['handle']} ({$handle['platform']}): {$followers} follower");
}

/* ─────────────────────────────────────────────────────────────────────────────
 * YOUTUBE DATA API v3 — COMMENTATA SU RICHIESTA (v0.3: solo Apify)
 * Conservata per riferimento futuro. Per riattivarla: decommentare,
 * aggiungere 'youtube_api_key' in config, e reindirizzare provider_fetch_handle.
 * ─────────────────────────────────────────────────────────────────────────────

function youtube_fetch(array $handle, string $apiKey): array
{
    // 1. Resolve handle → channel ID
    $url = 'https://www.googleapis.com/youtube/v3/channels?part=statistics,contentDetails'
         . '&forHandle=' . urlencode($handle['handle']) . '&key=' . urlencode($apiKey);
    // ... chiamata cURL, parsing statistics.subscriberCount ...
    // 2. playlistItems per gli ultimi video
    // 3. videos?part=statistics per like/view/commenti
    // Normalizzazione identica a apify_normalize_youtube.
    return ['ok' => false, 'error' => 'disabled', 'posts' => 0];
}

 * ───────────────────────────────────────────────────────────────────────────*/

// ── Rimozione completa di un handle e dati collegati (v0.8) ───────────────────

/**
 * Elimina definitivamente un handle e TUTTI i dati collegati:
 * post (in tutte le partizioni), metriche giornaliere, indice snapshot.
 * Ritorna conteggi di ciò che è stato rimosso.
 */
function provider_purge_handle(int $handleId): array
{
    $removed = ['posts' => 0, 'metrics' => 0, 'snapshots' => 0, 'handle' => 0];

    // Post in tutte le partizioni
    $storePath = CW_DATA . '/db/posts';
    if (is_dir($storePath)) {
        $partitions = glob($storePath . '/[0-9][0-9][0-9][0-9]-[0-9][0-9]', GLOB_ONLYDIR) ?: [];
        foreach ($partitions as $pdir) {
            foreach (glob($pdir . '/*.json') ?: [] as $file) {
                $rec = _db_read_file($file);
                if ($rec && (int)($rec['handle_id'] ?? 0) === $handleId) {
                    unlink($file);
                    $removed['posts']++;
                }
            }
        }
    }

    // Metriche giornaliere
    $removed['metrics'] = db_delete_where('metrics_daily', ['handle_id' => $handleId]);

    // Indice snapshot
    $removed['snapshots'] = db_delete_where('snapshots_index', ['handle_id' => $handleId]);

    // L'handle stesso
    if (db_delete('handles', $handleId)) $removed['handle'] = 1;

    return $removed;
}
