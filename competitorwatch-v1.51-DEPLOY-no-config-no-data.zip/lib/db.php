<?php
declare(strict_types=1);

/**
 * CompetitorWatch — Storage Layer
 *
 * Schema-on-write JSON file store.
 * Interface mirrors PDO patterns so migration to MySQL
 * requires rewriting ONLY this file.
 *
 * Layout:
 *   data/db/{store}/          each store = a directory
 *   data/db/{store}/{id}.json each record = one JSON file
 *   data/db/{store}/_seq      auto-increment counter
 *
 * Posts are partitioned by month:
 *   data/db/posts/{YYYY-MM}/{id}.json
 *
 * Thread safety: PHP flock() on every write.
 */

// ── Internal helpers ─────────────────────────────────────────────────────────

function _db_root(): string
{
    return CW_DATA . '/db';
}

function _db_store_path(string $store): string
{
    return _db_root() . '/' . $store;
}

/**
 * Read a JSON file safely. Returns null on failure.
 */
function _db_read_file(string $path): ?array
{
    if (!file_exists($path)) return null;
    $raw = file_get_contents($path);
    if ($raw === false) return null;
    $data = json_decode($raw, true);
    return is_array($data) ? $data : null;
}

/**
 * Write a JSON file atomically using a temp file + rename.
 * flock() on the destination prevents race conditions.
 */
function _db_write_file(string $path, array $data): bool
{
    $dir = dirname($path);
    if (!is_dir($dir)) {
        mkdir($dir, 0750, true);
    }

    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    if ($json === false) return false;

    // Write to temp file then rename (atomic on POSIX)
    $tmp = $path . '.tmp.' . getmypid();
    if (file_put_contents($tmp, $json, LOCK_EX) === false) {
        return false;
    }
    return rename($tmp, $path);
}

/**
 * Get next auto-increment ID for a store.
 */
function _db_next_id(string $storePath): int
{
    $seqFile = $storePath . '/_seq';
    $fp = fopen($seqFile, 'c+');
    if (!$fp) return (int)microtime(true); // fallback

    flock($fp, LOCK_EX);
    $val = (int)(stream_get_contents($fp) ?: '0');
    $next = $val + 1;
    ftruncate($fp, 0);
    rewind($fp);
    fwrite($fp, (string)$next);
    flock($fp, LOCK_UN);
    fclose($fp);
    return $next;
}

/**
 * Ensure store directory exists.
 */
function _db_ensure_store(string $store): string
{
    $path = _db_store_path($store);
    if (!is_dir($path)) {
        mkdir($path, 0750, true);
    }
    return $path;
}

// ── Public API ───────────────────────────────────────────────────────────────

/**
 * Insert a record. Returns the new ID.
 * For posts, pass partition like 'posts/2026-05'.
 */
function db_insert(string $store, array $data): int
{
    $storePath = _db_ensure_store($store);
    $id = _db_next_id($storePath);
    $data['_id'] = $id;
    $data['_created_at'] = date('c');
    $filePath = $storePath . '/' . $id . '.json';
    _db_write_file($filePath, $data);
    return $id;
}

/**
 * Find one record by ID.
 */
function db_find_by_id(string $store, int $id): ?array
{
    $path = _db_store_path($store) . '/' . $id . '.json';
    return _db_read_file($path);
}

/**
 * Find all records in a store matching optional filters.
 * $filters = ['field' => 'value'] — all conditions ANDed.
 * $limit = 0 means no limit.
 * $order_by = 'field', $order_dir = 'asc'|'desc'
 */
/**
 * Confronto valore-filtro robusto per i record JSON.
 * - bool e null richiedono corrispondenza ESATTA di tipo (false ≠ 0 ≠ '' ≠ null)
 * - scalari (int/float/string) confrontati per valore con cast a stringa
 *   (JSON può restituire "5" o 5 a seconda della sorgente)
 */
function _db_match_value(mixed $recordVal, mixed $filterVal): bool
{
    if (is_bool($filterVal) || is_bool($recordVal) || $filterVal === null || $recordVal === null) {
        return $recordVal === $filterVal;
    }
    if (is_scalar($recordVal) && is_scalar($filterVal)) {
        return (string)$recordVal === (string)$filterVal;
    }
    return $recordVal === $filterVal;
}

function db_find(
    string $store,
    array  $filters   = [],
    int    $limit     = 0,
    int    $offset    = 0,
    string $order_by  = '_id',
    string $order_dir = 'asc'
): array {
    $storePath = _db_store_path($store);
    if (!is_dir($storePath)) return [];

    $results = [];

    // For partitioned stores (e.g. posts/2026-05) scan directly;
    // for top-level stores, scan all files.
    $files = glob($storePath . '/*.json');
    if ($files === false) return [];

    foreach ($files as $file) {
        $record = _db_read_file($file);
        if ($record === null) continue;

        $match = true;
        foreach ($filters as $key => $value) {
            if (!array_key_exists($key, $record)) { $match = false; break; }
            if (!_db_match_value($record[$key], $value)) { $match = false; break; }
        }
        if ($match) $results[] = $record;
    }

    // Sort
    usort($results, function ($a, $b) use ($order_by, $order_dir) {
        $av = $a[$order_by] ?? '';
        $bv = $b[$order_by] ?? '';
        $cmp = is_numeric($av) && is_numeric($bv)
            ? $av <=> $bv
            : strcmp((string)$av, (string)$bv);
        return $order_dir === 'desc' ? -$cmp : $cmp;
    });

    // Offset + limit
    if ($offset > 0) $results = array_slice($results, $offset);
    if ($limit  > 0) $results = array_slice($results, 0, $limit);

    return $results;
}

/**
 * Find records across all partitions of a store (e.g. all posts).
 * $store = 'posts', partitions are subdirectories named YYYY-MM.
 */
function db_find_partitioned(
    string $store,
    array  $filters   = [],
    int    $limit     = 0,
    int    $offset    = 0,
    string $order_by  = '_id',
    string $order_dir = 'desc',
    ?string $partition_from = null,  // e.g. '2026-01'
    ?string $partition_to   = null   // e.g. '2026-05'
): array {
    $storePath = _db_store_path($store);
    if (!is_dir($storePath)) return [];

    $partitions = glob($storePath . '/[0-9][0-9][0-9][0-9]-[0-9][0-9]', GLOB_ONLYDIR);
    if (!$partitions) return [];

    sort($partitions);

    $results = [];
    foreach ($partitions as $pdir) {
        $pname = basename($pdir);
        if ($partition_from && $pname < $partition_from) continue;
        if ($partition_to   && $pname > $partition_to)   continue;

        $files = glob($pdir . '/*.json');
        if (!$files) continue;
        foreach ($files as $file) {
            $record = _db_read_file($file);
            if ($record === null) continue;
            $match = true;
            foreach ($filters as $key => $value) {
                if (!array_key_exists($key, $record)) { $match = false; break; }
                if (!_db_match_value($record[$key], $value)) { $match = false; break; }
            }
            if ($match) $results[] = $record;
        }
    }

    usort($results, function ($a, $b) use ($order_by, $order_dir) {
        $av = $a[$order_by] ?? '';
        $bv = $b[$order_by] ?? '';
        $cmp = is_numeric($av) && is_numeric($bv)
            ? $av <=> $bv
            : strcmp((string)$av, (string)$bv);
        return $order_dir === 'desc' ? -$cmp : $cmp;
    });

    if ($offset > 0) $results = array_slice($results, $offset);
    if ($limit  > 0) $results = array_slice($results, 0, $limit);

    return $results;
}

/**
 * Count records matching filters.
 */
function db_count(string $store, array $filters = []): int
{
    return count(db_find($store, $filters));
}

/**
 * Update a record by ID. Merges $data into existing record.
 * Returns false if record not found.
 */
function db_update(string $store, int $id, array $data): bool
{
    $storePath = _db_store_path($store);
    $filePath  = $storePath . '/' . $id . '.json';
    $existing  = _db_read_file($filePath);
    if ($existing === null) return false;

    unset($data['_id'], $data['_created_at']); // protect meta fields
    $updated = array_merge($existing, $data);
    $updated['_updated_at'] = date('c');
    return _db_write_file($filePath, $updated);
}

/**
 * Update records in partitioned store by matching filters.
 */
function db_update_partitioned(string $store, array $filters, array $data): int
{
    $storePath = _db_store_path($store);
    if (!is_dir($storePath)) return 0;

    $partitions = glob($storePath . '/[0-9][0-9][0-9][0-9]-[0-9][0-9]', GLOB_ONLYDIR);
    if (!$partitions) return 0;

    $count = 0;
    foreach ($partitions as $pdir) {
        $files = glob($pdir . '/*.json');
        if (!$files) continue;
        foreach ($files as $file) {
            $record = _db_read_file($file);
            if ($record === null) continue;
            $match = true;
            foreach ($filters as $key => $value) {
                if (!_db_match_value($record[$key] ?? null, $value)) { $match = false; break; }
            }
            if (!$match) continue;
            unset($data['_id'], $data['_created_at']);
            $updated = array_merge($record, $data);
            $updated['_updated_at'] = date('c');
            _db_write_file($file, $updated);
            $count++;
        }
    }
    return $count;
}

/**
 * Delete a record by ID. Returns false if not found.
 */
function db_delete(string $store, int $id): bool
{
    $path = _db_store_path($store) . '/' . $id . '.json';
    if (!file_exists($path)) return false;
    return unlink($path);
}

/**
 * Upsert: find by filters, update if found, insert if not.
 * Returns ['action' => 'insert'|'update', 'id' => int]
 */
function db_upsert(string $store, array $filters, array $data): array
{
    $existing = db_find($store, $filters, 1);
    if ($existing) {
        $id = (int)$existing[0]['_id'];
        db_update($store, $id, $data);
        return ['action' => 'update', 'id' => $id];
    }
    $id = db_insert($store, array_merge($filters, $data));
    return ['action' => 'insert', 'id' => $id];
}

/**
 * Insert into partitioned store (posts).
 * $partition = 'YYYY-MM'
 */
function db_insert_partitioned(string $store, string $partition, array $data): int
{
    $storePath = _db_store_path($store);
    $partPath  = $storePath . '/' . $partition;
    if (!is_dir($partPath)) mkdir($partPath, 0750, true);

    // Use combined seq across all partitions: store-level seq
    _db_ensure_store($store);
    $id = _db_next_id($storePath);
    $data['_id'] = $id;
    $data['_partition'] = $partition;
    $data['_created_at'] = date('c');
    $filePath = $partPath . '/' . $id . '.json';
    _db_write_file($filePath, $data);
    return $id;
}

/**
 * Check if a record exists (deduplication).
 */
function db_exists(string $store, array $filters): bool
{
    return !empty(db_find($store, $filters, 1));
}

/**
 * Append to an array field in a record (e.g. audit log lines).
 * Creates record if not found (by filters).
 */
function db_append_to(string $store, array $filters, string $field, mixed $value): void
{
    $existing = db_find($store, $filters, 1);
    if ($existing) {
        $id  = (int)$existing[0]['_id'];
        $arr = $existing[0][$field] ?? [];
        if (!is_array($arr)) $arr = [];
        $arr[] = $value;
        db_update($store, $id, [$field => $arr]);
    } else {
        db_insert($store, array_merge($filters, [$field => [$value]]));
    }
}

/**
 * Delete all records in a store matching filters.
 * Returns number deleted.
 */
function db_delete_where(string $store, array $filters): int
{
    $records = db_find($store, $filters);
    $count = 0;
    foreach ($records as $r) {
        if (db_delete($store, (int)$r['_id'])) $count++;
    }
    return $count;
}

/**
 * Delete old partition directories older than $months.
 */
function db_prune_partitions(string $store, int $months): int
{
    $storePath = _db_store_path($store);
    if (!is_dir($storePath)) return 0;

    $cutoff = date('Y-m', strtotime("-{$months} months"));
    $partitions = glob($storePath . '/[0-9][0-9][0-9][0-9]-[0-9][0-9]', GLOB_ONLYDIR);
    if (!$partitions) return 0;

    $deleted = 0;
    foreach ($partitions as $pdir) {
        if (basename($pdir) < $cutoff) {
            $files = glob($pdir . '/*');
            if ($files) foreach ($files as $f) unlink($f);
            rmdir($pdir);
            $deleted++;
        }
    }
    return $deleted;
}

/**
 * Database health check. Returns array of issues (empty = healthy).
 */
function db_health_check(): array
{
    $issues = [];
    $root = _db_root();

    if (!is_dir($root)) {
        $issues[] = "data/db/ non esiste";
        return $issues;
    }
    if (!is_writable($root)) {
        $issues[] = "data/db/ non è scrivibile";
    }

    // Test write
    $testFile = $root . '/.write_test_' . getmypid();
    if (file_put_contents($testFile, '1') === false) {
        $issues[] = "Impossibile scrivere in data/db/";
    } else {
        unlink($testFile);
    }

    // Check NFS (flock unreliable on NFS)
    $statfs = @shell_exec('stat -f -c %T ' . escapeshellarg($root) . ' 2>/dev/null');
    if ($statfs && str_contains(strtolower(trim($statfs)), 'nfs')) {
        $issues[] = "Filesystem NFS rilevato: flock() inaffidabile. Spostare data/ su filesystem locale.";
    }

    return $issues;
}
