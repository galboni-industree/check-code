<?php
declare(strict_types=1);

/**
 * CompetitorWatch — Alert Engine (v0.5)
 *
 * Rileva segnali sui CONCORRENTI (non solo sul sistema), calcolati
 * gratuitamente dai dati già raccolti, a ogni fetch di un handle.
 *
 * Tipi:
 *   engagement_spike — un post supera Nx la media del competitor
 *   volume_spike     — volume settimanale +X% vs media
 *   follower_jump    — variazione follower giornaliera oltre Y%
 *   format_change    — primo post di un nuovo formato
 *   silence          — nessun post da N giorni
 *   new_hashtag      — hashtag mai visto su più post
 *
 * Tutti gli alert sono deduplicati per (type, handle, giorno).
 */

/**
 * Valuta tutti gli alert per un handle dopo un fetch.
 * Chiamato da job_fetch_handle.
 */
function alerts_evaluate_handle(array $handle): void
{
    if (!config('alerts.enabled', true)) return;

    $hid       = (int)$handle['_id'];
    $cid       = (int)$handle['competitor_id'];
    $platform  = (string)$handle['platform'];
    $compName  = alerts_competitor_name($cid);

    // Carica i post recenti del competitor (ultimi 2 mesi, abbastanza per medie)
    $from = date('Y-m', strtotime('-2 months'));
    $to   = date('Y-m');
    $posts = db_find_partitioned('posts', ['handle_id' => $hid], 0, 0, 'posted_at', 'desc', $from, $to);

    alerts_check_engagement_spike($handle, $compName, $posts);
    alerts_check_volume_spike($handle, $compName, $posts);
    alerts_check_follower_jump($handle, $compName);
    alerts_check_format_change($handle, $compName, $posts);
    alerts_check_silence($handle, $compName, $posts);
    alerts_check_new_hashtag($handle, $compName, $posts);
}

// ── Singoli rilevatori ────────────────────────────────────────────────────────

function alerts_check_engagement_spike(array $handle, string $compName, array $posts): void
{
    $threshold = (float)config('alerts.engagement_spike_x', 3.0);
    if (count($posts) < 5) return; // serve una base statistica

    $eng = array_map(fn($p) => (int)$p['likes'] + (int)$p['comments'], $posts);
    $avg = array_sum($eng) / count($eng);
    if ($avg <= 0) return;

    // Controlla solo i post pubblicati nelle ultime 48h (i "nuovi")
    $recent = array_filter($posts, fn($p) => !empty($p['posted_at'])
        && strtotime((string)$p['posted_at']) > time() - 172800);

    foreach ($recent as $p) {
        $e = (int)$p['likes'] + (int)$p['comments'];
        if ($e >= $avg * $threshold) {
            $ratio = round($e / $avg, 1);
            alerts_emit('engagement_spike', $handle,
                sprintf('%s (%s): un post ha fatto %dx la media (%d engagement vs media %d). Testo: "%s"',
                    $compName, platform_label((string)$handle['platform']), $ratio,
                    $e, round($avg), mb_substr((string)$p['text'], 0, 80)),
                'spike_' . ($p['external_id'] ?? ''));
        }
    }
}

function alerts_check_volume_spike(array $handle, string $compName, array $posts): void
{
    $pct = (float)config('alerts.volume_spike_pct', 50);

    // Post per settimana nelle ultime 4 settimane complete
    $now = time();
    $weeks = [0, 0, 0, 0];
    foreach ($posts as $p) {
        if (empty($p['posted_at'])) continue;
        $age = $now - strtotime((string)$p['posted_at']);
        $w = (int)floor($age / 604800);
        if ($w >= 0 && $w < 4) $weeks[$w]++;
    }

    $thisWeek = $weeks[0];
    $baseline = ($weeks[1] + $weeks[2] + $weeks[3]) / 3;
    if ($baseline < 1) return; // niente storico affidabile

    if ($thisWeek >= $baseline * (1 + $pct / 100) && $thisWeek >= 3) {
        $inc = round((($thisWeek - $baseline) / $baseline) * 100);
        alerts_emit('volume_spike', $handle,
            sprintf('%s (%s): volume post +%d%% questa settimana (%d post vs media %.1f). Possibile campagna in corso.',
                $compName, platform_label((string)$handle['platform']), $inc, $thisWeek, $baseline),
            'vol_' . date('Y-W'));
    }
}

function alerts_check_follower_jump(array $handle, string $compName): void
{
    $pct = (float)config('alerts.follower_jump_pct', 5.0);
    $hid = (int)$handle['_id'];

    $metrics = db_find('metrics_daily', ['handle_id' => $hid], 0, 0, 'date', 'desc');
    if (count($metrics) < 2) return;

    $today = (int)($metrics[0]['followers'] ?? 0);
    $prev  = (int)($metrics[1]['followers'] ?? 0);
    if ($prev <= 0) return;

    $change = (($today - $prev) / $prev) * 100;
    if (abs($change) >= $pct) {
        $dir = $change > 0 ? 'balzo' : 'crollo';
        alerts_emit('follower_jump', $handle,
            sprintf('%s (%s): %s follower %+.1f%% in un giorno (%d → %d). Da investigare.',
                $compName, platform_label((string)$handle['platform']), $dir, $change, $prev, $today),
            'foll_' . ($metrics[0]['date'] ?? date('Y-m-d')));
    }
}

function alerts_check_format_change(array $handle, string $compName, array $posts): void
{
    if (count($posts) < 3) return;

    // Formati storici (oltre 7 giorni fa) vs nuovi (ultimi 7 giorni)
    $now = time();
    $old = []; $new = [];
    foreach ($posts as $p) {
        $fmt = (string)($p['media_type'] ?? '');
        if (!$fmt) continue;
        $age = empty($p['posted_at']) ? PHP_INT_MAX : $now - strtotime((string)$p['posted_at']);
        if ($age > 604800) $old[$fmt] = true;
        else $new[$fmt] = true;
    }
    if (!$old) return;

    foreach (array_keys($new) as $fmt) {
        if (!isset($old[$fmt])) {
            alerts_emit('format_change', $handle,
                sprintf('%s (%s): nuovo formato "%s" mai usato prima. Possibile cambio di strategia contenuti.',
                    $compName, platform_label((string)$handle['platform']), $fmt),
                'fmt_' . $fmt);
        }
    }
}

function alerts_check_silence(array $handle, string $compName, array $posts): void
{
    $days = (int)config('alerts.silence_days', 10);
    if (!$posts) return;

    $latest = 0;
    foreach ($posts as $p) {
        if (!empty($p['posted_at'])) $latest = max($latest, strtotime((string)$p['posted_at']));
    }
    if ($latest === 0) return;

    $silentDays = (int)floor((time() - $latest) / 86400);
    if ($silentDays >= $days) {
        alerts_emit('silence', $handle,
            sprintf('%s (%s): nessun post da %d giorni. Account fermo o handle cambiato?',
                $compName, platform_label((string)$handle['platform']), $silentDays),
            'silence_' . date('Y-W')); // un alert a settimana max
    }
}

function alerts_check_new_hashtag(array $handle, string $compName, array $posts): void
{
    $now = time();
    $recentTags = []; $oldTags = [];
    foreach ($posts as $p) {
        $age = empty($p['posted_at']) ? PHP_INT_MAX : $now - strtotime((string)$p['posted_at']);
        foreach ((array)($p['hashtags'] ?? []) as $h) {
            if ($age > 1209600) $oldTags[$h] = true;        // > 2 settimane
            else $recentTags[$h] = ($recentTags[$h] ?? 0) + 1;
        }
    }
    // Hashtag nuovo che appare su 2+ post recenti
    foreach ($recentTags as $tag => $count) {
        if ($count >= 2 && !isset($oldTags[$tag])) {
            alerts_emit('new_hashtag', $handle,
                sprintf('%s (%s): nuovo hashtag ricorrente #%s (%d post). Possibile nuova campagna o posizionamento.',
                    $compName, platform_label((string)$handle['platform']), $tag, $count),
                'tag_' . $tag);
        }
    }
}

// ── Helpers ───────────────────────────────────────────────────────────────────

function alerts_competitor_name(int $cid): string
{
    $c = db_find_by_id('competitors', $cid);
    return $c['name'] ?? "#{$cid}";
}

/**
 * Emit alert with dedup. $dedupKey distingue istanze nello stesso giorno.
 */
function alerts_emit(string $type, array $handle, string $message, string $dedupKey): void
{
    $today = date('Y-m-d');
    $key   = $type . '_' . (int)$handle['_id'] . '_' . $dedupKey . '_' . $today;

    if (db_exists('alerts', ['dedup' => $key])) return;

    db_insert('alerts', [
        'type'          => $type,
        'dedup'         => $key,
        'competitor_id' => (int)$handle['competitor_id'],
        'handle_id'     => (int)$handle['_id'],
        'message'       => $message,
        'read'          => false,
        'date'          => $today,
    ]);
    cw_log('info', "Alert {$type}: {$message}");
}
