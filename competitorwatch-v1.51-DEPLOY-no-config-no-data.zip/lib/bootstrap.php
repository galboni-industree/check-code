<?php
declare(strict_types=1);

// ── PHP version guard ────────────────────────────────────────────────────────
if (PHP_VERSION_ID < 80200) {
    http_response_code(500);
    exit('CompetitorWatch richiede PHP 8.2 o superiore. Versione rilevata: ' . PHP_VERSION);
}

// ── Polyfill mbstring ────────────────────────────────────────────────────────
// Rete di sicurezza: se la CLI (o il web) non ha mbstring, definiamo gli
// equivalenti minimi usati dall'app. Funzionano correttamente con UTF-8.
// Se mbstring è presente, questo blocco viene saltato.
if (!function_exists('mb_substr')) {
    function mb_substr($string, $start, $length = null, $encoding = 'UTF-8') {
        $string = (string)$string;
        if (preg_match_all('/./us', $string, $m) === false) {
            return substr($string, $start, $length ?? PHP_INT_MAX);
        }
        $chars = $m[0];
        $slice = array_slice($chars, $start, $length);
        return implode('', $slice);
    }
}
if (!function_exists('mb_strlen')) {
    function mb_strlen($string, $encoding = 'UTF-8') {
        return preg_match_all('/./us', (string)$string, $tmp);
    }
}
if (!function_exists('mb_strtolower')) {
    function mb_strtolower($string, $encoding = 'UTF-8') {
        return strtolower((string)$string); // approssimato per accenti, sufficiente per hashtag
    }
}
if (!function_exists('mb_strtoupper')) {
    function mb_strtoupper($string, $encoding = 'UTF-8') {
        return strtoupper((string)$string);
    }
}
if (!function_exists('mb_str_split')) {
    function mb_str_split($string, $length = 1, $encoding = 'UTF-8') {
        preg_match_all('/./us', (string)$string, $m);
        if ($length <= 1) return $m[0];
        $chunks = [];
        for ($i = 0, $n = count($m[0]); $i < $n; $i += $length) {
            $chunks[] = implode('', array_slice($m[0], $i, $length));
        }
        return $chunks;
    }
}


// ── Paths ────────────────────────────────────────────────────────────────────
define('CW_ROOT',    dirname(__DIR__));
define('CW_LIB',     CW_ROOT . '/lib');
define('CW_VIEWS',   CW_ROOT . '/views');
define('CW_DATA',    CW_ROOT . '/data');
define('CW_CONFIG',  CW_ROOT . '/config');
define('CW_ASSETS',  CW_ROOT . '/assets');

// ── Config ───────────────────────────────────────────────────────────────────
$configFile = CW_CONFIG . '/config.php';
if (!file_exists($configFile)) {
    if (PHP_SAPI === 'cli') {
        fwrite(STDERR, "config.php mancante: completa prima l'installazione via browser (install.php).\n");
        exit(1);
    }
    // Redirect to installer (only if not already there)
    $script = $_SERVER['SCRIPT_NAME'] ?? '';
    if (!str_ends_with($script, 'install.php')) {
        header('Location: install.php');
        exit;
    }
    return; // allow install.php to load without config
}
$GLOBALS['cw_config'] = require $configFile;

// ── Timezone ─────────────────────────────────────────────────────────────────
$tz = $GLOBALS['cw_config']['timezone'] ?? 'Europe/Rome';
date_default_timezone_set($tz);

// ── Autoload libs ────────────────────────────────────────────────────────────
require_once CW_LIB . '/helpers.php';
require_once CW_LIB . '/security.php';
require_once CW_LIB . '/db.php';
require_once CW_LIB . '/auth.php';

// ── Output buffering (web only) ──────────────────────────────────────────────
// Cattura eventuali warning/notice così redirect() può scartarli ed evitare
// lo "schermo bianco" (header Location inviato dopo output accidentale).
if (PHP_SAPI !== 'cli') {
    ob_start();
}

// ── HTTPS enforcement (skip in CLI) ──────────────────────────────────────────
if (PHP_SAPI !== 'cli') {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https')
            || (($_SERVER['SERVER_PORT'] ?? 80) == 443);

    if (!$isHttps) {
        // Show warning but don't hard-block during install
        $script = $_SERVER['SCRIPT_NAME'] ?? '';
        if (!str_ends_with($script, 'install.php')) {
            http_response_code(403);
            exit('<h1>HTTPS richiesto</h1><p>Accedi tramite https://</p>');
        }
    }

    // Security headers
    header('X-Frame-Options: DENY');
    header('X-Content-Type-Options: nosniff');
    header('Referrer-Policy: same-origin');
    if ($isHttps) {
        header('Strict-Transport-Security: max-age=31536000; includeSubDomains');
    }
}

// ── Session (web only) ───────────────────────────────────────────────────────
if (PHP_SAPI !== 'cli' && session_status() === PHP_SESSION_NONE) {
    $isHttps = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
            || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');

    // Derive cookie path from script location
    $cookiePath = rtrim(dirname($_SERVER['SCRIPT_NAME'] ?? '/'), '/') . '/';
    if ($cookiePath === '//') $cookiePath = '/';

    session_set_cookie_params([
        'lifetime' => (int)($GLOBALS['cw_config']['security']['session_lifetime'] ?? 3600),
        'path'     => $cookiePath,
        'secure'   => $isHttps,
        'httponly' => true,
        'samesite' => 'Strict',
    ]);
    session_name('cw_session');
    session_start();
}
